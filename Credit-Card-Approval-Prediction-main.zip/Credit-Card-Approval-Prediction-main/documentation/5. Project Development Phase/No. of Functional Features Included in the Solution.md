# No. of Functional Features Included in the Solution

This document lists and validates the functional features implemented in the Credit Card Approval Prediction System, categorized by frontend web portal features and backend machine learning pipeline features.

---

## 1. Web Portal Functional Features (Frontend/UI)

- [x] **Home Landing Page (`home.html`):**
  - Displays project overview, models compared, selection rules, and details of prediction outputs.
  - Contains navigation buttons to the application form.
- [x] **Applicant Prediction Form Page (`index.html`):**
  - Features 17 input fields covering demographic, financial, and credit history variables.
  - Pre-populates credit summary inputs with standard default values (e.g., `-24` for open month, `24` for window) to reduce typing overhead.
- [x] **Validation Error Banners:**
  - Performs validation checks on form submission. If validation fails (e.g. `annual_income <= 0`), the page re-renders with a danger alert banner showing the error description, preserving the entered form values.
- [x] **Result Page (`result.html`):**
  - Displays predicted status ("Approved" or "Not Approved") in large, bold text.
  - Renders prediction confidence score as a percentage (e.g., `99.47%` confidence).
  - Displays the selected best model's name (e.g., `XGBoost`).
- [x] **Top-3 Local Explanation Cards:**
  - Displays the top-3 features influencing that specific prediction.
  - Labeled with dynamic directions: "increased approval likelihood" (green-themed) or "decreased approval likelihood" (red/orange-themed).

---

## 2. Machine Learning Pipeline Features (Backend)

- [x] **Raw CSV Data Loader:**
  - Automatically loads and joins `application_record.csv` and `credit_record.csv` from the `data/` directory.
- [x] **Duplicate ID Cleaning:**
  - Identifies and drops duplicate applicant records in the application dataset based on customer ID, keeping the first occurrence.
- [x] **Monthly Repayment Aggregator:**
  - Converts monthly transactional rows into customer-level aggregates: open month, end month, window, count of clean months, overdue months, and severe delinquencies.
- [x] **Imbalanced Class Balancing:**
  - Sets `class_weight='balanced'` for Logistic Regression, Decision Tree, and Random Forest.
  - Configures `scale_pos_weight` dynamically for XGBoost to balance positive and negative ratio classes.
- [x] **Evaluation Metric Logging:**
  - Computes and exports Accuracy, Precision, Recall, F1, ROC-AUC, PR-AUC, and 5-fold cross-validated accuracy for all 4 models to `reports/model_comparison.csv`.
- [x] **F1-Score Automated Selector:**
  - Compares test performance and selects the best model based on F1-score.
- [x] **Visualization Generators:**
  - Generates combined ROC and Precision-Recall comparison plots.
  - Generates global feature importance or coefficient bar plots for the selected best model.
- [x] **Unified Pipeline Serialization:**
  - Persists the fitted `preprocessor.pkl` ColumnTransformer and the best model `model.pkl` bundle.
