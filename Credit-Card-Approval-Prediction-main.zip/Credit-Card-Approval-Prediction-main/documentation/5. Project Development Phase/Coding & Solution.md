# Coding & Solution

This document explains the core coding solutions and algorithmic implementations in `train.py` and `app.py`.

---

## 1. Credit History Aggregation & Target Mapping

To map multiple monthly payment records (`credit_record.csv`) to a single applicant ID, `train.py` implements the `aggregate_credit_history` function.

```python
def aggregate_credit_history(credit_df: pd.DataFrame) -> pd.DataFrame:
    cdf = credit_df.copy()
    cdf["MONTHS_BALANCE"] = pd.to_numeric(cdf["MONTHS_BALANCE"], errors="coerce")
    cdf["STATUS"] = cdf["STATUS"].astype(str)

    def summarize(group: pd.DataFrame) -> pd.Series:
        statuses = group["STATUS"].tolist()
        open_month = group["MONTHS_BALANCE"].min()
        end_month = group["MONTHS_BALANCE"].max()
        credit_window = end_month - open_month

        months_no_loan = sum(s == "X" for s in statuses)
        months_paid = sum(s == "C" for s in statuses)
        months_overdue = sum(s in {"0", "1", "2", "3", "4", "5"} for s in statuses)
        severe_delinquency_count = sum(s in {"3", "4", "5"} for s in statuses)

        # Proxy target mapping:
        target = int(any(s in {"0", "1", "2", "3", "4", "5"} for s in statuses))

        return pd.Series({
            "credit_open_month": open_month,
            "credit_end_month": end_month,
            "credit_window": credit_window,
            "months_no_loan": months_no_loan,
            "months_paid": months_paid,
            "months_overdue": months_overdue,
            "severe_delinquency_count": severe_delinquency_count,
            "target": target
        })

    aggregated = cdf.groupby("ID", as_index=False).apply(summarize).reset_index(drop=True)
    return aggregated
```

- **Target Definition:** A proxy target is created. An application is flagged as **Not Approved (1)** if their payment status history ever contains a code between `0` (1-29 days overdue) and `5` (150+ days overdue). It is marked as **Approved (0)** if all recorded monthly statuses are clean (`C` or `X`).

---

## 2. Handling the `DAYS_EMPLOYED` Placeholder

The raw dataset contains a placeholder value of `365243` for unemployed or retired applicants, representing 1000 years of employment. Left raw, this value distorts scales and tree splits.

```python
def handle_days_employed(series: pd.Series) -> pd.Series:
    cleaned = series.copy()
    cleaned = cleaned.replace(365243, np.nan)
    cleaned = cleaned.where(cleaned <= 0, np.nan)
    employment_years = (cleaned.abs() / 365.25).fillna(0.0)
    return employment_years
```

- **Algorithm:** The function replaces the placeholder with `NaN`, keeps negative day values (representing days in the past), divides the absolute values by `365.25` to convert to years, and fills missing values with `0.0` (assuming 0 years of active employment).

---

## 3. Directional Factor Explainer Algorithm

During inference in `app.py`, the system determines the top-3 factors that drove the decision using the `local_top_factors` algorithm.

```python
def local_top_factors(
    transformed_vector: np.ndarray,
    model_bundle: Dict[str, Any],
    top_n: int = 3,
) -> List[Dict[str, str]]:
    feature_names = model_bundle["feature_names"]
    explanation = model_bundle["explanation"]
    method = explanation["method"]

    x = transformed_vector.ravel()

    if method == "logistic_coefficients":
        # Signed linear contribution per feature
        signs = np.array(explanation["direction"])
        mags = np.array(explanation["global_importance"])
        contribution = x * signs * mags
    else:
        # Proxy directional local influence for tree models
        importances = np.array(explanation["global_importance"])
        direction = np.array(explanation["direction"])
        centers = np.array(explanation["centers"])
        contribution = (x - centers) * direction * importances

    top_idx = np.argsort(np.abs(contribution))[::-1][:top_n]

    factors: List[Dict[str, str]] = []
    for idx in top_idx:
        toward_rejection = contribution[idx] > 0
        factors.append({
            "feature": labelify(feature_names[idx]),
            "effect": (
                "decreased approval likelihood"
                if toward_rejection
                else "increased approval likelihood"
            )
        })
    return factors
```

- **Logic:**
  - For Logistic Regression, feature contribution is the scaled input multiplied by the coefficient.
  - For tree-based models, a proxy contribution is calculated by taking the distance of the input value from the training set median, multiplied by the feature's correlation direction (positive correlation means higher values correlate with rejections) and the global feature importance.
  - The feature effects are labeled as **decreased approval likelihood** (positive contribution toward Class 1) or **increased approval likelihood** (negative contribution).
