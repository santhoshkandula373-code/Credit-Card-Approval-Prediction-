# Project Planning

This document details the project timeline, milestones, task breakdowns, and dependencies for the Credit Card Approval Prediction System.

---

## 1. Project Timeline (2-Week Development Sprint)

The development of the system is divided into five sequential phases across a two-week sprint:

```text
Phase 1: Ingestion & Requirements (Days 1-2)  [====]
Phase 2: Data Aggregation & EDA (Days 3-5)        [======]
Phase 3: Model Pipeline & Training (Days 6-8)           [======]
Phase 4: Web Portal & UI (Days 9-11)                          [======]
Phase 5: Testing & Release Docs (Days 12-14)                        [====]
```

### Detailed Phase Breakdown

| Phase | Duration | Tasks | Deliverables |
| :--- | :---: | :--- | :--- |
| **Phase 1: Ingestion & Requirements** | Days 1-2 | <ul><li>Define underwriting problem and proxy labels.</li><li>Outline technology stack and environment requirements.</li><li>Analyze Kaggle source dataset schema.</li></ul> | <ul><li>`requirements.txt`</li><li>Problem statements & personas</li></ul> |
| **Phase 2: Data Aggregation & EDA** | Days 3-5 | <ul><li>Write credit status aggregator.</li><li>Clean duplicate IDs.</li><li>Conduct correlation analysis and generate countplots.</li></ul> | <ul><li>`train.py` (data loading & cleaning)</li><li>`eda_correlation_heatmap.png`</li><li>`eda_countplots.png`</li></ul> |
| **Phase 3: Model Pipeline & Training** | Days 6-8 | <ul><li>Build Scikit-Learn preprocessing transformers.</li><li>Train Logistic Regression, Decision Tree, Random Forest, and XGBoost.</li><li>Evaluate metrics and serialize best model based on F1-score.</li></ul> | <ul><li>`preprocessor.pkl`</li><li>`model.pkl`</li><li>`model_comparison.csv`</li><li>`roc_curve.png`</li></ul> |
| **Phase 4: Web Portal & UI** | Days 9-11 | <ul><li>Build Flask web daemon with endpoint routing.</li><li>Design HTML templates (`home.html`, `index.html`, `result.html`).</li><li>Implement form validation and top-3 explanation drivers.</li></ul> | <ul><li>`app.py`</li><li>Flask HTML templates</li><li>Local Explainer engine</li></ul> |
| **Phase 5: Testing & Release Docs** | Days 12-14 | <ul><li>Run verification testing script.</li><li>Conduct manual form validation audits.</li><li>Compile structured project documentation directories.</li></ul> | <ul><li>`walkthrough.md`</li><li>`documentation/` directory</li></ul> |

---

## 2. Project Milestone Gates

1. **Gate 1: Data Verification (Day 3)**
   - *Requirement:* Data successfully merged from `application_record.csv` and `credit_record.csv` with zero duplicate IDs and verified target mapping.
2. **Gate 2: Modeling Complete (Day 8)**
   - *Requirement:* All 4 classifiers evaluated, reports exported to `/reports`, and model/preprocessor successfully pickled with F1 score > 90%.
3. **Gate 3: UI Integration Complete (Day 11)**
   - *Requirement:* Form submission, numeric value checking, and local explanations rendering correctly without server crashes.
4. **Gate 4: Document Verification (Day 14)**
   - *Requirement:* All 23 template topics created and populated with project details.
