# Team Involvement in Demonstration

This document defines the team role allocations and presentation duties for demonstrating the Credit Card Approval Prediction System.

---

## 1. Presentation Roles and Assignments

To ensure a professional and comprehensive delivery, presentation duties are divided among the core engineering and product roles:

| Presenter Role | Project Member | Session Segment | Key Delivery Points |
| :--- | :--- | :--- | :--- |
| **Project Manager** | Team Member 1 | <ul><li>Introduction & Welcome</li><li>Business Case Context</li><li>Q&A Moderation</li></ul> | <ul><li>Manual underwriting inefficiencies.</li><li>The value of automated risk assessment.</li><li>Executive summary & project wrap-up.</li></ul> |
| **Data Engineer** | Team Member 2 | <ul><li>Data Ingestion & Cleaning</li><li>Feature Engineering</li><li>Pipeline Serialization</li></ul> | <ul><li>Merging applicant profiles and credit record history.</li><li>Aggregating monthly records into customer rows.</li><li>Fitted `preprocessor.pkl` ColumnTransformer.</li></ul> |
| **ML Engineer** | Team Member 3 | <ul><li>Modeling & Tuning</li><li>Performance Comparison</li><li>Model Serialization</li></ul> | <ul><li>Comparing Logistic Regression, Decision Trees, Random Forests, and XGBoost.</li><li>Evaluating via F1 score to address class imbalances.</li><li>Explaining the target leakage diagnostic analysis.</li></ul> |
| **Frontend Developer** | Team Member 4 | <ul><li>Web Application Demo</li><li>Input Validation Checks</li><li>Explainability walkthrough</li></ul> | <ul><li>Navigating `/` and `/predict`.</li><li>Simulating validation warning behaviors.</li><li>Demonstrating the Local Explainer cards.</li></ul> |

---

## 2. Team Q&A Preparation Rules

During the demonstration review panel, team members are assigned to answer specific questions:
- **Data Engineering questions** (e.g. duplicate resolution, null imputation strategies) are routed to the **Data Engineer**.
- **Model Tuning and Performance questions** (e.g. class weighting, F1-scores, target leakage causes) are routed to the **ML Engineer**.
- **User Interface and Integration questions** (e.g. Flask routing, Bootstrap layouts, security check fields) are routed to the **Frontend Developer**.
- **Business Value questions** (e.g. project costs, regulatory compliance, adverse action policies) are routed to the **Project Manager**.
