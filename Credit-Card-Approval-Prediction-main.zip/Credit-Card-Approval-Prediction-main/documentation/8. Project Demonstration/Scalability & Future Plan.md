# Scalability & Future Plan

This document outlines the architectural roadmap and scalability plans to evolve the Credit Card Approval Prediction System into an enterprise-grade production platform.

---

## 1. Action Plan to Resolve Target Leakage

To make the machine learning model viable for real-world underwriting of new credit applicants, the target leakage must be resolved:

### The Problem
Currently, the training script uses credit repayment summaries (`months_overdue`, `severe_delinquency_count`) as features to predict a target label that is directly derived from those same columns. New applicants do not have this history, making the model unusable.

### The Fix
1. **Remove Credit Summary Features:** Modify the feature list in `train.py` to exclude all variables computed from `credit_record.csv`:
   - Exclude: `credit_open_month`, `credit_end_month`, `credit_window`, `months_no_loan`, `months_paid`, `months_overdue`, `severe_delinquency_count`.
2. **Train on Demographic/Financial Data Only:** Limit training features strictly to profile details:
   - Include: `gender`, `annual_income`, `age_years`, `employment_years`, `education_type`, `family_status`, `housing_type`, `occupation_type`, `children_count`, `family_members`, `family_dependency`.
3. **Incorporate External Bureau Scores:** In a production setting, append the applicant's external credit score (e.g. FICO rating) to the demographic features.
4. **Evaluate Realistic Performance:** Re-train the models. The metrics will drop from the perfect $1.0$ accuracy down to a realistic range (e.g. $70\% - 82\%$ F1-score), but the resulting model will be fully deployable for scoring new applicants.

---

## 2. Cloud Architecture & Infrastructure Scale

To transition the local Flask app into a highly available cloud service, the following architecture is proposed:

```text
                  +-----------------------------------+
                  |        DNS / Route 53             |
                  +-----------------+-----------------+
                                    |
                                    v
                  +-----------------+-----------------+
                  |      Application Load Balancer    |
                  +-----------------+-----------------+
                                    |
            +-----------------------+-----------------------+
            |                                               |
            v                                               v
+-----------+-----------+                       +-----------+-----------+
|    ECS Docker Instance|                       |    ECS Docker Instance|
|    (Flask app.py)     |                       |    (Flask app.py)     |
+-----------+-----------+                       +-----------+-----------+
            |                                               |
            +-----------------------+-----------------------+
                                    | Logs Transaction
                                    v
                  +-----------------+-----------------+
                  |      PostgreSQL / RDS Database     |
                  |     (Audits predictions & inputs) |
                  +-----------------+-----------------+
```

- **Containerization (Docker):** Wrap the Flask daemon, dependencies, templates, and serialized `.pkl` models into a lightweight Docker image.
- **Serverless Hosting:** Deploy the Docker container to AWS Fargate or Google Cloud Run to auto-scale dynamically based on incoming API traffic.
- **Transaction Logging Database:** Set up a database (e.g., PostgreSQL or DynamoDB) to log every prediction request, including applicant demographics, model confidence, and the top-3 influential factors returned, supporting future audit requirements.

---

## 3. Model Operations (MLOps) & Drift Detection

Once deployed, the model's accuracy will drift over time due to changes in applicant profiles (e.g. shifts in average income due to inflation). We will implement:

- **Data Drift Monitoring:** A monthly scheduled cron script using libraries like `Evidently AI` or `Alibi Detect` to check if the statistical distribution of demographic inputs has diverged from the training split baseline.
- **Automated Feedback Loop:** Integrate a scheduled batch retraining pipeline. If drift metrics exceed predefined statistical thresholds, the pipeline will pull new repayment data, re-train the models, and deploy the updated artifacts.
- **Continuous Integration (CI/CD):** Set up GitHub Actions to run unit tests and check file configurations (`requirements.txt`) before building and pushing new production images.
