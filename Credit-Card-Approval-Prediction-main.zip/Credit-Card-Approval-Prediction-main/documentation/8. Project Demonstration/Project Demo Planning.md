# Project Demo Planning

This document outlines the agenda, setup instructions, and key talking points for demonstrating the Credit Card Approval Prediction System to project evaluators or stakeholders.

---

## 1. Demo Agenda (15-Minute Session)

The demonstration is structured into five brief modules:

1. **Problem Statement & Business Context (2 Minutes)**
   - *Presenter:* Risk Analyst Lead.
   - *Content:* Outline the manual underwriting bottleneck and the need for objective, automated, and explainable risk scores. Explain the proxy-target assumption (deriving approval status from credit records).
2. **Data Pipeline & Preprocessing Architecture (3 Minutes)**
   - *Presenter:* Data Engineer.
   - *Content:* Explain the dual-table merge, placeholder cleaning (`DAYS_EMPLOYED`), and the unified `ColumnTransformer` serialization pattern.
3. **ML Training & Evaluation Analysis (4 Minutes)**
   - *Presenter:* ML Engineer.
   - *Content:* Walk through the comparison of the four classifiers. Address the class imbalance treatments. Show the global feature importance charts.
   - *Highlight:* Address the 100% metrics and explain the target leakage diagnostic transparently.
4. **Live System Walkthrough (4 Minutes)**
   - *Presenter:* Frontend Developer.
   - *Content:* Demonstrate landing page navigation, boundary validation checks (Test Case 2), a high-risk applicant decision (Test Case 3), and a low-risk applicant decision (Test Case 4). Focus on the Local Explainer cards.
5. **Future Roadmap & Scalability (2 Minutes)**
   - *Presenter:* Tech Lead.
   - *Content:* Discuss fixing target leakage, cloud deployment, and model drift monitoring.

---

## 2. Pre-Demo Setup Checklist

Before presenting, ensure the following steps are completed:

- [ ] **Data Ready:** Confirm raw CSV datasets are located in `/data` and the environment packages are active.
- [ ] **Artifacts Generated:** Confirm `train.py` has run successfully and created `model.pkl` and `preprocessor.pkl`.
- [ ] **Web Server Active:** Start the Flask app server (`python app.py`) and verify that no startup errors are logged.
- [ ] **Browser Ready:** Open the web browser to `http://127.0.0.1:5000/` and zoom to $100\%$ or $110\%$ for clear visibility.
- [ ] **Test Inputs Ready:** Have the inputs for Scenario A (Low-Risk) and Scenario B (High-Risk) copy-pasted in a side text editor to prevent typing delays during the live demo.

---

## 3. Key Presentation Talking Points

- **Explainability is Mandatory:** Emphasize that black-box classifiers are regulatory liabilities in financial risk scoring. Highlight how our Local Explainer helps risk officers understand *why* the model made a specific prediction.
- **F1 Score over Accuracy:** Explain that accuracy is a flawed metric for credit applications due to heavy class skew. The model selection algorithm uses the F1-Score to balance credit risk and growth.
- **Transparency on Target Leakage:** Instead of hiding the perfect 100% tree metrics, proactively discuss **target leakage** as a design constraint of using historical payment aggregates in the training feature columns. This demonstrates robust engineering awareness.
