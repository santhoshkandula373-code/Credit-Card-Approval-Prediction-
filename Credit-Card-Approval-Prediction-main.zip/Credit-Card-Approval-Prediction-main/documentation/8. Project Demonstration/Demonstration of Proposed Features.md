# Demonstration of Proposed Features

This document provides a step-by-step user acceptance testing (UAT) script to demonstrate and verify the features of the Credit Card Approval Prediction System.

---

## User Acceptance Testing (UAT) Script

Follow these steps to demonstrate the application to stakeholders or review committees:

### Test Case 1: Landing Page Navigation
1. Open a browser and load the URL: `http://127.0.0.1:5000/`.
2. **Verify:** Check that the page title displays "Credit Card Approval Prediction System".
3. **Verify:** Check that the landing page displays:
   - A list of the models compared (Logistic Regression, Decision Tree, Random Forest, XGBoost).
   - A brief explanation of the model selection criterion (F1-score).
   - What outputs the prediction page will generate (prediction, confidence, top 3 factors).
4. Click the green button: **"Go To Prediction Form"**.
5. **Result:** The page successfully transitions to `/predict`.

---

### Test Case 2: Validation Check (Invalid Input)
1. On the form page (`/predict`), input:
   - **Age:** `15` (younger than the legal limit of 18).
   - **Annual Income:** `0` (or leave empty).
2. Click the yellow button: **"Predict"**.
3. **Verify:** The application does not crash.
4. **Verify:** The page re-renders, displaying a red warning banner: `"Age must be greater than 18 years."` (or `"Annual income must be greater than 0."`).
5. **Verify:** Check that all other entries you entered remain pre-populated in their input fields.

---

### Test Case 3: High-Risk Applicant Submission
1. In the input form, enter the following values:
   - **Gender:** Male, **Income Type:** Working
   - **Annual Income:** `110000`, **Age:** `30`, **Employment Duration:** `1.5`
   - **Education:** Secondary, **Housing:** Rented apartment, **Family Status:** Single
   - **Children:** `0`, **Family Members:** `1`
   - **Credit History Summary:**
     - Credit Open Month: `-12`, Credit End Month: `0`, Credit Window: `12`
     - Months No Loan: `2`, Months Paid: `4`
     - **Months Overdue:** `6` (overdue payments recorded)
     - **Severe Delinquency Count:** `2` (long overdue periods)
2. Click **"Predict"**.
3. **Verify:** The page transitions to `/predict` (POST) and displays the result container.
4. **Verify:** The outcome status is clearly labeled **Not Approved**.
5. **Verify:** The confidence score is shown as `100.0%` (using Decision Tree best model).
6. **Verify:** The top-3 factors card lists **Months Overdue** as a driver that **decreased approval likelihood**.

---

### Test Case 4: Low-Risk Applicant Submission
1. Click the link **"Go Back and Try Another"** on the results page.
2. In the input form, enter the following values:
   - **Gender:** Female, **Income Type:** Commercial associate
   - **Annual Income:** `300000`, **Age:** `40`, **Employment Duration:** `10.0`
   - **Education:** Higher education, **Housing:** House / apartment, **Family Status:** Married
   - **Children:** `0`, **Family Members:** `2`
   - **Credit History Summary:**
     - Credit Open Month: `-48`, Credit End Month: `0`, Credit Window: `48`
     - Months No Loan: `0`, Months Paid: `48`
     - **Months Overdue:** `0` (clean repayment history)
     - **Severe Delinquency Count:** `0`
3. Click **"Predict"**.
4. **Verify:** The outcome status is clearly labeled **Approved**.
5. **Verify:** The confidence score is shown as `100.0%`.
6. **Verify:** The top-3 factors card lists **Months Overdue** and **Annual Income** as drivers that **increased approval likelihood**.
