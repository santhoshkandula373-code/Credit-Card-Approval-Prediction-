# Proposed Solution

This document details the system specifications, data preprocessing pipeline, modeling workflow, and explainability mechanisms of the Credit Card Approval Prediction System.

---

## 1. Data Processing & Preprocessing Pipeline

The application ingestion pipeline features unified preprocessing using Scikit-Learn's `ColumnTransformer` to prevent inference drift. The pipeline splits the features into three primary pathways:

1. **Categorical Feature Branch:**
   - Features: `gender`, `income_type`, `education_type`, `family_status`, `housing_type`, `occupation_type`.
   - Treatment: Imputed with the most frequent value (`SimpleImputer`), then mapped to numeric values using `OrdinalEncoder`. 
   - Unknown handling is configured with `handle_unknown="use_encoded_value"` and `unknown_value=-1` to prevent crashes when new categories are submitted.
2. **Raw Numeric Feature Branch (Tree Models):**
   - Features: All numeric columns (income, age, employment, credit summary values).
   - Treatment: Imputed with the median value (`SimpleImputer`). Tree-based models (Decision Tree, Random Forest, XGBoost) use these raw, unscaled numeric branches.
3. **Scaled Numeric Feature Branch (Logistic Regression):**
   - Features: Same numeric columns.
   - Treatment: Imputed with the median value and normalized using `StandardScaler` to ensure stable gradient convergence during optimization.

---

## 2. Machine Learning Classifiers

Four classifiers are evaluated under hardcoded random seed settings (`random_state=42`):

- **Logistic Regression:**
  - *Solver:* `liblinear` (ideal for smaller/medium datasets).
  - *Imbalance Handling:* `class_weight='balanced'`.
- **Decision Tree Classifier:**
  - *Imbalance Handling:* `class_weight='balanced'`.
- **Random Forest Classifier:**
  - *Parameters:* `n_estimators=300`, `n_jobs=-1`.
  - *Imbalance Handling:* `class_weight='balanced'`.
- **XGBoost Classifier:**
  - *Parameters:* `n_estimators=300`, `learning_rate=0.05`, `max_depth=5`.
  - *Imbalance Handling:* `scale_pos_weight = negative_samples / positive_samples` to balance class weights dynamically.

---

## 3. Best Model Selection Strategy

Rather than using accuracy (which can be misleadingly high on imbalanced datasets), the models are evaluated and ranked based on their **F1-Score**:

$$\text{F1} = 2 \times \frac{\text{Precision} \times \text{Recall}}{\text{Precision} + \text{Recall}}$$

The training script automatically compares the F1-Score on the test set, saves the ranking table as `reports/model_comparison.csv`, and serializes the highest-scoring model to `saved_model/model.pkl`.

---

## 4. Local Explainer Algorithm (Model Interpretability)

To comply with adverse-action requirements, the system includes a **Local Top-3 Factors Explainer** in `app.py`:

- **For Logistic Regression:**
  $$\text{Contribution} = x_{\text{scaled}} \times \text{sign}(\text{coefficient}) \times |\text{coefficient}|$$
- **For Tree-Based Models (Proxy Method):**
  $$\text{Contribution} = (x_{\text{input}} - \text{median}_{\text{train}}) \times \text{sign}(\text{correlation}) \times \text{importance}_{\text{global}}$$

The three features with the highest absolute contribution scores are returned. If a feature's contribution score is positive, it pushes the prediction toward `Not Approved` (decreased approval likelihood). If negative, it pushes it toward `Approved` (increased approval likelihood).
