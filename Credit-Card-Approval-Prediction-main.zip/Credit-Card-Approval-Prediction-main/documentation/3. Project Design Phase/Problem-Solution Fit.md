# Problem-Solution Fit

This document analyzes the fit between the problem requirements of retail credit card risk management and the machine learning solution implemented.

---

## 1. Mapping Problems to Solutions

| User Problem & Need | Solution Feature | Fit Justification |
| :--- | :--- | :--- |
| **High Financial Loss from Defaults**<br>The bank needs to identify applicants likely to default (overdue status). | **Advanced Ensemble Classifiers** (Random Forest, XGBoost). | Standard classifiers fail on skewed credit datasets. By training multiple models and tuning weights to handle imbalanced data, the system successfully identifies high-risk applications. |
| **Regulatory Audit & Explainability**<br>Regulators require a reason for credit denials (Adverse Action Notice). | **Local Directional Factor Explainer** (Top-3 reasons). | The application doesn't just output a yes/no. It calculates the top-3 influential features for each specific transaction, indicating if a feature increased or decreased approval likelihood. |
| **Underwriting Preprocessing Inconsistency**<br>Inconsistent categorical labels or numeric scaling between training and inference. | **Unified ColumnTransformer Serialization** (`preprocessor.pkl`). | Both categorical imputers/encoders and numeric transformers are saved in a single pipeline object, preventing discrepancies between offline training and live deployment. |
| **Manual Data Processing Overhead**<br>Evaluating applicant risk takes days. | **Flask Instant Real-Time Scoring Interface** (`app.py`). | Simplifies the workflow into an instant, user-friendly form that performs input parsing, validation, prediction, and explanations in under 250ms. |

---

## 2. Fit Evaluation

### Business Value Fit
- **Objective Decisions:** Traditional credit review can be subjective. An ML classification engine provides an objective, repeatable score.
- **Explainable Automation:** The local explainer ensures compliance with the Equal Credit Opportunity Act (ECOA) by explaining rejection drivers, such as low income or high historical delinquencies.

### Technical Limitations & Leakage Caveat
While the problem-solution fit is strong, the model's reliance on **credit history variables** (`months_overdue`) for predicting approvals introduces a circular relationship (target leakage). For a *new applicant* with no card history, the model's current fit is impaired because credit window details are not yet generated. To achieve full production-readiness, the feature set must be limited strictly to demographic and external bureau scores.
