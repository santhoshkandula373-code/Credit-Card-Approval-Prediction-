# Solution Architecture

This document describes the layered system architecture of the Credit Card Approval Prediction System, mapping component boundaries and data persistence.

---

## 1. Layered Architecture Diagram

The system is structured into four distinct layers, following a decoupled machine learning design pattern:

```text
+---------------------------------------------------------------------------------+
|                               PRESENTATION LAYER                                |
|   - templates/home.html (Landing Page)                                          |
|   - templates/index.html (Applicant Input Form with validation warnings)        |
|   - templates/result.html (Decision Notification, Confidence, Explanations)    |
+------------------------------------+--------------------------------------------+
                                     | Form POST Data / HTML Response
                                     v
+---------------------------------------------------------------------------------+
|                                APPLICATION LAYER                                |
|   - app.py (Flask Web App Daemon)                                               |
|   - Input Parsing & Validation Rules (income > 0, age > 18, etc.)               |
|   - Interpretability Engine (local_top_factors computation)                     |
+------------------------------------+--------------------------------------------+
                                     | Calls Preprocessor & Model Predict
                                     v
+---------------------------------------------------------------------------------+
|                             MACHINE LEARNING LAYER                              |
|   - train.py (Offline Pipeline Script)                                          |
|   - Preprocessing Pipeline (SimpleImputer, OrdinalEncoder, StandardScaler)      |
|   - Model Selection Engine (F1 scoring comparison of 4 models)                  |
+------------------------------------+--------------------------------------------+
                                     | Reads/Writes Artifacts & CSVs
                                     v
+---------------------------------------------------------------------------------+
|                                   DATA LAYER                                    |
|   - Raw Data: application_record.csv, credit_record.csv in data/                 |
|   - Exported Splits: train_split_train.csv, train_split_test.csv in reports/     |
|   - Serialized: saved_model/preprocessor.pkl, saved_model/model.pkl             |
|   - Performance Artifacts: reports/model_comparison.csv, plots, classification  |
+---------------------------------------------------------------------------------+
```

---

## 2. Key Architecture Design Decisions

### Separation of Concerns (Offline vs. Online)
- **Offline Training (`train.py`):** Heavy operations such as data loading, cleaning, merging tables, training multiple estimators, cross-validating, and exporting large diagnostic plots are handled offline. This script is run periodically to update models.
- **Online Inference (`app.py`):** Live server does not import training libraries (like seaborn/matplotlib) or load raw CSV records. It only loads the pre-fitted `preprocessor.pkl` and `model.pkl` at startup, ensuring near-instant predictions (<250ms).

### Unified Preprocessing Serialization
Rather than serializing categorical encoders and numeric scalers separately, they are combined in one `ColumnTransformer` object (`preprocessor.pkl`). This ensures that:
- Any preprocessing changes made in `train.py` are automatically inherited by `app.py` upon reload, preventing code synchronization bugs.
- Preprocessing pipelines remain sealed and self-contained.

### Inbound Boundary Input Validation
Before calling the ML layer, the application layer validates parameters (e.g., rejecting ages under 18 or negative employment). This prevents feeding invalid vectors to Scikit-Learn, which would otherwise result in mathematical exceptions or garbage outputs.
