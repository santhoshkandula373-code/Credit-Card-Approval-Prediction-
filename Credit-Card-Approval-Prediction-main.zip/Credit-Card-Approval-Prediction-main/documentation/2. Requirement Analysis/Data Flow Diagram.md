# Data Flow Diagram (DFD)

This document visualizes the data flow inside the Credit Card Approval Prediction System. It is divided into the **Training Pipeline DFD** (offline) and the **Live Prediction DFD** (online).

---

## 1. Offline Training Pipeline DFD (Level-1)

This flow occurs when `train.py` is executed to ingest datasets, preprocess features, train models, and save artifacts.

```mermaid
graph TD
    A1[(application_record.csv)] -->|Load Raw App Data| B[Data Cleaning & Feature Engineering]
    A2[(credit_record.csv)] -->|Load Raw Credit Data| C[Aggregate Credit History & Proxy Target Map]
    
    B -->|Merged by ID| D[Merged DataFrame]
    C -->|Merged by ID| D
    
    D -->|Target Split & Stratification| E[train_test_split]
    E -->|Train Set 80%| F[X_train, y_train]
    E -->|Test Set 20%| G[X_test, y_test]
    
    F -->|Fit Preprocessor| H[ColumnTransformer Preprocessing]
    H -->|Transform Train Data| I[Preprocessed X_train]
    G -->|Transform Test Data| J[Preprocessed X_test]
    
    I -->|Train Models| K{Four ML Classifiers}
    J -->|Predict & Evaluate| K
    
    K -->|Logistic Regression| L[Logistic Regression Model]
    K -->|Decision Tree| M[Decision Tree Model]
    K -->|Random Forest| N[Random Forest Model]
    K -->|XGBoost| O[XGBoost Model]
    
    L & M & N & O -->|F1-based Selection| P[Select Best Model]
    
    P -->|Save Model & Metadata| Q[saved_model/model.pkl]
    H -->|Save Fitted Preprocessor| R[saved_model/preprocessor.pkl]
    
    L & M & N & O -->|Generate Outputs| S[(reports/ Files & Plots)]
```

---

## 2. Online Inference DFD (Level-1)

This flow occurs at runtime when a user fills out the Flask application form and requests a prediction.

```mermaid
graph TD
    User([Applicant / Underwriter]) -->|1. Demographics & Credit Summary| Form[templates/index.html Form]
    Form -->|2. POST Request Payload| Route["/predict (Flask app.py)"]
    
    Route -->|3. Validate Inputs| Val{"Input Valid?"}
    Val -->|No: Error Message| Form
    
    Val -->|Yes: Create DataFrame| DF[Single-Row DataFrame]
    
    DF -->|4. Load Preprocessor| PrepPkg[(saved_model/preprocessor.pkl)]
    PrepPkg -->|5. Fit/Transform Pipeline| TransVector[Transformed Feature Vector]
    
    TransVector -->|6. Load Best Model| ModelPkg[(saved_model/model.pkl)]
    ModelPkg -->|7. Model.predict_proba| PredEngine[Inference Engine]
    
    PredEngine -->|8. Raw Probabilities| Explainer[Directional Factor Explainer]
    ModelPkg -->|Get Importance Coefficients| Explainer
    
    Explainer -->|9. Top-3 Influential Factors| ResPage[templates/result.html]
    PredEngine -->|Prediction & Confidence| ResPage
    
    ResPage -->|10. View Approval Status & Explanations| User
```
