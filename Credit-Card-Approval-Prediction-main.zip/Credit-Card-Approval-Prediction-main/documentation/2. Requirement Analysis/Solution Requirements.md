# Solution Requirements

This document outlines the Functional and Non-Functional Requirements for the Credit Card Approval Prediction System.

---

## 1. Functional Requirements (FR)

### FR-1: Demographic & Financial Input Capturing
The system must capture the following applicant parameters via a web form interface:
- **Gender:** Categorical selection (Male, Female).
- **Income Type:** Text input (e.g., Working, Pensioner, State servant).
- **Annual Income:** Positive floating-point numeric value (local currency).
- **Age (Years):** Positive numeric value (must be $> 18$ years).
- **Employment Duration (Years):** Non-negative numeric value.
- **Education Type:** Text input (e.g., Higher education, Secondary).
- **Housing Type:** Text input (e.g., House/apartment, Rented apartment).
- **Family Status:** Text input (e.g., Married, Single).
- **Occupation Type:** Text input (e.g., Laborers, Core staff).
- **Children Count:** Non-negative integer value.
- **Family Members:** Integer value $\ge 1$.

### FR-2: Historical Repayment Input Capturing
The system must capture the following monthly credit history summary fields:
- **Credit Open Month / End Month / Window:** Integer parameters specifying the customer's credit relationship duration.
- **Months No Loan (X):** Count of months with no active loan balance.
- **Months Paid (C):** Count of months where payments were settled on time.
- **Months Overdue (0-5):** Count of months with overdue balances.
- **Severe Delinquency Count (3-5):** Count of months with overdue periods exceeding 90 days.

### FR-3: Server-Side Input Validation
The Application layer (`app.py`) must enforce validation criteria before proceeding to the ML inference stage:
- Reject with warning if `annual_income <= 0`.
- Reject with warning if `age_years <= 18`.
- Reject with warning if `employment_years < 0`.
- Reject with warning if `children_count < 0`.
- Reject with warning if `family_members < 1`.
- Verify all dropdown categorical values and text inputs are populated.

### FR-4: Preprocessing & Classification Execution
- The server must pass inputs through the persisted Scikit-Learn `ColumnTransformer` object (`preprocessor.pkl`).
- The system must predict the proxy underwriting outcome using the selected best classifier (Logistic Regression, Decision Tree, Random Forest, or XGBoost) saved in `model.pkl`.
- Imbalance in the target variable must be automatically addressed in model parameters (e.g. using `class_weight='balanced'` or `scale_pos_weight`).

### FR-5: Outcome Notification & Explainability (Adverse Action notice)
The results page (`result.html`) must display:
- **Underwriting Prediction:** Clear text status ("Approved" or "Not Approved").
- **Confidence Score:** Percentage value (e.g., `85.5%` confidence).
- **Top-3 Influential Factors:** A list of the three features that had the largest impact on this specific outcome, marked with their direction (e.g., *"Age: increased approval likelihood"* or *"Months Overdue: decreased approval likelihood"*).

---

## 2. Non-Functional Requirements (NFR)

### NFR-1: Low Inference Latency
- The average prediction cycle (from form submit to rendering the result page) must be **under 250 milliseconds** on local development machines, ensuring a responsive user experience.

### NFR-2: Robust Preprocessing Drift-Control
- Numeric imputers, categorical encoders, and scalers must be bundled into a **single serialized pipeline artifact** (`preprocessor.pkl`). This ensures that during online inference, the input features are processed in exactly the same way as they were during offline model training, preventing encoding errors or schema drift.
- Unknown categories entered in the text inputs must be mapped to a default token (e.g., OrdinalEncoder unknown value of `-1`) rather than raising a system exception.

### NFR-3: Portability & Offline Reproducibility
- The system must operate fully offline, requiring no external cloud resources.
- All dependencies must be listed in a `requirements.txt` file, specifying library versions to guarantee cross-machine compatibility.
- Random states must be hardcoded (e.g., `random_state=42`) across train/test splits and estimators to ensure reproducibility of the evaluation metrics.
