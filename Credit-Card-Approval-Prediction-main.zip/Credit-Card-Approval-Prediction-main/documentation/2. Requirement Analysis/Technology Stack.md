# Technology Stack

This document describes the software technologies, packages, and frameworks utilized to construct the Credit Card Approval Prediction System.

---

## 1. Core Frameworks & Runtime

- **Programming Language:** Python (v3.8 or higher recommended)
  - Selected for its rich ecosystem of data science, machine learning, and web development libraries.
- **Web Application Server:** Flask (v3.0.3)
  - A lightweight, modular Python micro-framework selected because it is easy to set up, requires minimal boilerplate, and integrates seamlessly with serialized Python machine learning objects via joblib.

---

## 2. Data Science & Machine Learning Libraries

- **Pandas (v2.2.2):** Used for ingestion of large application and credit CSV files, duplicate detection, inner joining, feature aggregation (using `groupby` and `apply` constructs), and exporting split datasets.
- **NumPy (v1.26.4):** Used for multidimensional array manipulations, handling missing indices, extracting prediction probability scores, and sorting feature importance indices.
- **Scikit-Learn (v1.5.0):** The primary machine learning toolkit used for:
  - *Data Preprocessing:* `ColumnTransformer`, `Pipeline`, `SimpleImputer`, `OrdinalEncoder`, `StandardScaler`.
  - *Classification Algorithms:* `LogisticRegression`, `DecisionTreeClassifier`, `RandomForestClassifier`.
  - *Evaluation Metrics:* `accuracy_score`, `precision_score`, `recall_score`, `f1_score`, `roc_auc_score`, `precision_recall_curve`, `auc`, `cross_val_score`.
- **XGBoost (v2.0.3):** Used to train the extreme gradient boosted classifier (`XGBClassifier`) with custom objective and evaluation metrics, demonstrating high-performance ensemble learning.
- **Joblib (v1.4.2):** Used for saving and loading fitted pipeline estimators (`preprocessor.pkl` and `model.pkl`) to disk.

---

## 3. Visualization & EDA Engines

- **Matplotlib (v3.9.0) & Seaborn (v0.13.2):** Used to generate and save statistical graphics during model training, including:
  - Demographic countplots (`eda_countplots.png`).
  - Correlation heatmaps (`eda_correlation_heatmap.png`).
  - Labeled confusion matrices (`confusion_matrix.png`).
  - ROC and Precision-Recall comparison plots (`roc_curve.png`, `precision_recall_curve.png`).
  - Global feature importance/coefficient graphs (`feature_importance.png`).

---

## 4. Presentation & Frontend Layer

- **HTML5 & CSS3:** For page structures, layouts, custom gradient variables, rise animations, and font settings.
- **Bootstrap (v5.3.3 CDN):** Integrated to provide responsive grid structures, stylized form inputs, danger alerts for input validation errors, success containers, and a clean professional appearance.
- **Google Fonts:** Integration of premium typography (e.g. Georgia, Serif, Trebuchet MS) to upgrade page aesthetics.
