# Customer Journey Map

This document maps out the end-to-end journey of an applicant applying for a credit card and a bank risk analyst auditing the automated prediction system.

---

## 1. Credit Card Applicant Journey Map

| Phase | 1. Access & Onboarding | 2. Form Submission | 3. Automated Processing | 4. Outcome & Explanation |
| :--- | :--- | :--- | :--- | :--- |
| **User Action** | Applicant visits the bank's portal, reads the product overview, and clicks "Go to Prediction Form". | Applicant fills in demographics (income, age, employment, education) and submits the form. | System runs validations, preprocesses the input, and runs the ML classifier. | System displays "Approved" or "Not Approved" with confidence and top 3 reasons. |
| **Touchpoint** | Portal Landing Page (`home.html`). | Form Input Page (`index.html`). | Flask Application Server backend (`app.py`). | Results Page (`result.html`). |
| **User Thoughts** | *"Is the page secure? Is it easy to use? What inputs are required?"* | *"Will my age or education type cause a rejection? Are my numbers accurate?"* | *"I hope this doesn't hang or crash. Why is it taking a few seconds?"* | *"Why was I rejected? Oh, it says my income and employment duration were the primary negative factors."* |
| **User Emotion** | Neutral, hopeful. | Slightly anxious, focused. | Suspenseful, waiting. | Relieved (if approved) or Informative (if rejected, due to clear explanation). |
| **Pain Points** | Hard to find landing page or slow load time. | Form validation errors without clear instructions. | App crashes due to non-numeric inputs. | Rejection without a reason causes frustration and brand abandonment. |
| **Opportunities** | Clean Bootstrap UI with list of outputs to expect. | Real-time HTML5 form validation and pre-populated defaults. | Rapid model inference with cached preprocessor. | Display the top 3 influencing factors to maintain transparency and compliance. |

---

## 2. Bank Underwriter Journey Map

| Phase | 1. System Set Up | 2. Model Training | 3. Evaluation & Review | 4. Production Auditing |
| :--- | :--- | :--- | :--- | :--- |
| **User Action** | Analyst installs dependencies and verifies application folder structure. | Runs training script (`train.py`) to process raw CSV records and train models. | Audits model evaluation metrics, ROC, PR curves, and feature importance. | Monitors live submissions and checks if predictions align with credit risk. |
| **Touchpoint** | Workspace Terminal (`requirements.txt`). | Terminal execution (`python train.py`). | `reports/` folder (CSV tables and PNG plot files). | Flask Console logs & Web interface. |
| **User Thoughts** | *"Are all required libraries specified with correct versions?"* | *"Are classes imbalanced? Will the training handle the 70:30 imbalance?"* | *"Did we select the model based on F1-score or Accuracy? Is there target leakage?"* | *"Are explanations matching actual risk parameters (e.g. debt history)?"* |
| **User Emotion** | Prepared, systematic. | Focused, analytical. | Critical, evaluative. | Confident, secure. |
| **Pain Points** | Dependency conflicts or missing data files. | Out-of-memory errors on massive data sets or long training times. | Model overfitting or target leakage leading to unrealistic 100% metrics. | "Black box" model outputs that cannot be explained to regulators. |
| **Opportunities** | Clear package lock file (`requirements.txt`). | Modular logging in training script to track preprocessing and splits. | Export machine-readable CSVs (`model_comparison.csv`) and plots. | Implement coefficient-based feature importance map (`preprocessor.pkl`). |
