# Project Executable Files

This document maps the project directory structure and provides execution instructions for the training pipeline and the web application.

---

## 1. Directory Tree Map

The directory structure of the Credit Card Approval Prediction System is organized as follows:

```text
Credit Card Approval Prediction System/
├── app.py                     # Flask web app server
├── train.py                   # Data preparation, EDA, modeling, and serialization
├── requirements.txt           # Python packages and version locks
├── README.md                  # Project overview and high-level setup guide
├── data/                      # Directory for raw datasets
│   ├── application_record.csv # Raw applicant demographic details (Kaggle)
│   └── credit_record.csv      # Raw monthly repayment status records (Kaggle)
├── saved_model/               # Output directory for serialized artifacts
│   ├── preprocessor.pkl       # Fitted pipeline ColumnTransformer
│   └── model.pkl              # Fitted best classifier model & interpretability metadata
├── templates/                 # Frontend HTML pages (Bootstrap 5)
│   ├── home.html              # Landing page
│   ├── index.html             # Applicant input form
│   └── result.html            # Prediction result & local explanation page
└── reports/                   # Model performance reports & EDA plots
    ├── accuracy.txt           # Test accuracy summary of all models
    ├── classification_report.txt  # Precision, recall, and F1 reports
    ├── model_comparison.csv   # Machine-readable performance table
    ├── confusion_matrix.png   # Confusion matrix heatmap (best model)
    ├── roc_curve.png          # ROC curve plot comparing all 4 models
    ├── precision_recall_curve.png # PR curve plot comparing all 4 models
    ├── feature_importance.png # Global feature importance / coefficients plot
    ├── train_split_train.csv  # Explicit training partition export
    ├── train_split_test.csv   # Explicit testing partition export
    ├── train_test_split_summary.txt # Summary of split row count & distributions
    ├── eda_countplots.png     # Distribution counts of categorical features
    ├── eda_correlation_heatmap.png # Numeric feature correlation heatmap
    └── eda_describe.csv       # Summary statistics of numeric columns
```

---

## 2. Setup and Installation

Follow these steps to set up the runtime environment and run the application locally:

### Step 1: Environment Isolation
Create and activate an isolated Python environment (e.g. using Anaconda or virtualenv):
```bash
# Using conda
conda create -n cc_approval python=3.10 -y
conda activate cc_approval

# Or using virtualenv
python -m venv .venv
# On Windows
.venv\Scripts\activate
# On macOS/Linux
source .venv/bin/activate
```

### Step 2: Install Package Dependencies
Install the required libraries listed in `requirements.txt`:
```bash
pip install -r requirements.txt
```

### Step 3: Raw Dataset Placement
Ensure that the Kaggle dataset files are placed in the `data/` folder:
- `data/application_record.csv`
- `data/credit_record.csv`

### Step 4: Run Training Pipeline
Execute `train.py` to aggregate records, run EDA, evaluate the 4 models, export metrics to the `reports/` folder, and serialize model files to the `saved_model/` folder:
```bash
python train.py
```

### Step 5: Start the Flask App Server
Run `app.py` to launch the local web server:
```bash
python app.py
```

### Step 6: Access Web Interface
Open your web browser and navigate to:
```text
http://127.0.0.1:5000/
```
From there, click the navigation buttons to submit applicant parameters and view risk predictions.
