# Sample Project Documentation

This document acts as an Integration and User Guide for the Credit Card Approval Prediction System, providing example payloads, expected outputs, and validation rules.

---

## 1. Web Application Form Inputs

The Flask endpoint `/predict` accepts form data submitted via HTTP `POST` requests. The expected form fields and data types are:

```json
{
  "gender": "Male | Female",
  "income_type": "Working | Pensioner | Commercial associate | State servant | Student",
  "education_type": "Higher education | Secondary / secondary special | Incomplete higher | Lower secondary | Academic degree",
  "family_status": "Married | Single / not married | Civil marriage | Separated | Widow",
  "housing_type": "House / apartment | Rented apartment | Municipal apartment | With parents | Co-op apartment | Office apartment",
  "occupation_type": "Laborers | Core staff | Sales staff | Managers | Drivers | ... | Unknown",
  "annual_income": 150000.00,
  "age_years": 34.5,
  "employment_years": 5.2,
  "children_count": 0,
  "family_members": 2,
  "credit_open_month": -24,
  "credit_end_month": 0,
  "credit_window": 24,
  "months_no_loan": 10,
  "months_paid": 14,
  "months_overdue": 0,
  "severe_delinquency_count": 0
}
```

---

## 2. API Integration & Scenario Examples

### Scenario A: Clean Record (Approved Applicant)

An applicant with stable employment, solid income, and a clean payment history.

#### Input Form Payload
- **Gender:** Female
- **Income Type:** Commercial associate
- **Education Type:** Higher education
- **Annual Income:** `280000.00`
- **Age:** `32.0`
- **Employment Duration:** `6.5` years
- **Housing Type:** House / apartment
- **Family Status:** Married
- **Occupation Type:** Managers
- **Children:** `0`, **Family Members:** `2`
- **Credit Summary:** Open: `-36`, End: `0`, Window: `36`, No Loan: `0`, Paid: `36`, Overdue: `0`, Severe Delinquencies: `0`

#### Rendered Result Context (`result.html`)
- **Status Outcome:** Approved
- **Confidence Score:** `100.0%`
- **Model Name:** Decision Tree
- **Top-3 Influential Factors:**
  1. *Months Overdue:* increased approval likelihood (since overdue months is 0).
  2. *Annual Income:* increased approval likelihood (high income compared to train median).
  3. *Employment Years:* increased approval likelihood (stable duration).

---

### Scenario B: Delinquent History (Not Approved Applicant)

An applicant with a history of overdue balances.

#### Input Form Payload
- **Gender:** Male
- **Income Type:** Working
- **Education Type:** Secondary / secondary special
- **Annual Income:** `120000.00`
- **Age:** `45.0`
- **Employment Duration:** `1.2` years
- **Housing Type:** Rented apartment
- **Family Status:** Single / not married
- **Occupation Type:** Laborers
- **Children:** `0`, **Family Members:** `1`
- **Credit Summary:** Open: `-12`, End: `0`, Window: `12`, No Loan: `2`, Paid: `6`, Overdue: `4`, Severe Delinquencies: `1`

#### Rendered Result Context (`result.html`)
- **Status Outcome:** Not Approved
- **Confidence Score:** `100.0%`
- **Model Name:** Decision Tree
- **Top-3 Influential Factors:**
  1. *Months Overdue:* decreased approval likelihood (due to `4` months overdue).
  2. *Severe Delinquency Count:* decreased approval likelihood (due to `1` severe delinquency).
  3. *Employment Years:* decreased approval likelihood (short employment tenure).

---

### Scenario C: Form Validation Failure

An applicant submits an invalid field value (e.g. an age under 18 years).

#### Input Form Payload
- **Annual Income:** `50000.00`
- **Age:** `16.0` (Violates constraint)

#### Rendered Output Response (`index.html` re-rendered)
- **Error Banner Message:** `Age must be greater than 18 years.`
- **Behavior:** The form is rendered again, preserving the customer's other entered entries, and displays a red warning banner alerting them of the invalid age.
