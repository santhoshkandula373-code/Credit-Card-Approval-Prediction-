# Empathy Map

This document contains empathy maps for the two main stakeholders of the Credit Card Approval Prediction System: the **Bank Underwriter (Risk Analyst)** and the **Credit Applicant**.

---

## 1. Stakeholder Persona 1: Bank Underwriter (Risk Analyst)

The Bank Underwriter is responsible for monitoring credit defaults, auditing model decisions, and complying with banking regulations.

```text
       SAYS: "I need to justify every rejection. Black-box models are a regulatory risk."
       THINKS: "Will this model approve high-risk applicants during an economic downturn?"
       DOES: Manually reviews flagged accounts, generates model reports, audits compliance.
       FEELS: Anxious about auditing, pressured by sales targets vs. default rate caps.
```

### Empathy Breakdown Table

| Dimension | Details |
| :--- | :--- |
| **What they THINK & FEEL** | <ul><li>"I want an automated process, but I must trust the features it uses."</li><li>"Is the model biased against specific demographic profiles?"</li><li>"How do I explain an automated rejection to the compliance officer?"</li></ul> |
| **What they HEAR** | <ul><li>From executives: "We need to speed up customer acquisition and cut underwriting overhead."</li><li>From regulators: "All automated decision engines must be audit-ready and explainable."</li></ul> |
| **What they SEE** | <ul><li>Reports showing default rates rising/falling.</li><li>Applicants complaining about unexplained rejections.</li><li>A clean dashboard presenting model accuracy, F1 score, and feature importances.</li></ul> |
| **What they SAY & DO** | <ul><li>They say: "Show me the top factors that caused this applicant's risk rating."</li><li>They do: Use the Flask app local explanations to verify decision boundaries.</li></ul> |
| **PAIN Points** | <ul><li>Fear of legal issues due to unexplained automated rejections.</li><li>Time wasted manually auditing edge cases.</li></ul> |
| **GAIN Desired** | <ul><li>A transparent, reliable prediction model that provides a clear confidence score and local feature importances (e.g. top-3 factors).</li></ul> |

---

## 2. Stakeholder Persona 2: Credit Card Applicant

The Applicant is a retail bank customer seeking a credit card for convenience, rewards, or building a credit history.

```text
       SAYS: "Why does it take so long to get approved? The form is too long."
       THINKS: "Is my income high enough? Will my application affect my credit score?"
       DOES: Submits personal details, scans documents, checks email for outcomes.
       FEELS: Anxious about rejection, frustrated by lack of transparency.
```

### Empathy Breakdown Table

| Dimension | Details |
| :--- | :--- |
| **What they THINK & FEEL** | <ul><li>"I hope they review my application fairly."</li><li>"I need to know immediately so I can apply elsewhere if rejected."</li><li>"Why do they ask for so much private demographic data?"</li></ul> |
| **What they HEAR** | <ul><li>From ads: "Get approved in minutes online!"</li><li>From friends: "Avoid bank X, they reject everyone without a reason."</li></ul> |
| **What they SEE** | <ul><li>A sleek, responsive online form that doesn't crash.</li><li>Either a flat "Approved" email or a standard rejection letter.</li></ul> |
| **What they SAY & DO** | <ul><li>They say: "I want an instant response so I can plan my finances."</li><li>They do: Fill out the prediction form on the web portal.</li></ul> |
| **PAIN Points** | <ul><li>Long waiting times for underwriting decisions.</li><li>Frustration when they are rejected without any explanation of what to improve (e.g., raise income, reduce debt).</li></ul> |
| **GAIN Desired** | <ul><li>Fast approval, transparent explanations, and actionable feedback if they are not approved.</li></ul> |
