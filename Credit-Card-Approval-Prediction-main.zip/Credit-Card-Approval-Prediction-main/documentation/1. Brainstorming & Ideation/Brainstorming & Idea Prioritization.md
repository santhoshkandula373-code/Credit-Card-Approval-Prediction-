# Brainstorming & Idea Prioritization

This document details the selection, scoping, and prioritization process that led to selecting the **Credit Card Approval Prediction System** over other alternative machine learning concepts.

## 1. Candidate Concepts Brainstormed

During the initial phase of the project, four primary machine learning applications in the retail banking and fintech domain were brainstormed:

1. **Credit Card Approval Prediction System** (Selected)
   - *Goal:* Predict application risk (approved vs. not approved) using demographic, income, and payment status history.
2. **Credit Card Fraud Transaction Detector**
   - *Goal:* Detect fraudulent transactions in real-time.
3. **Customer Churn Predictor for Credit Cards**
   - *Goal:* Predict whether an active credit card holder will close their account in the next 3 months.
4. **Credit Card Limit Optimization Engine**
   - *Goal:* Suggest optimal credit limit increases based on dynamic repayment behaviors.

---

## 2. Prioritization Framework & Matrix

To determine the most viable candidate for this academic development project, each concept was scored from 1 (lowest) to 5 (highest) across four dimensions:
- **Feasibility:** Availability of public high-quality datasets and complexity of preprocessing.
- **Business Impact:** Value generated for risk underwriting and decision automation.
- **Explainability Requirement:** Need for interpretable local/global predictions (crucial for regulatory compliance in lending).
- **Implementation Scope:** Feasibility of building an end-to-end ML model, evaluation reports, and a presentation web app within the given project timeframe.

### Prioritization Scoreboard

| Concept | Feasibility | Business Impact | Explainability Need | Implementation Scope | Total Score | Decision |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: |
| **Credit Card Approval Predictor** | **5** | **5** | **5** | **4** | **19 / 20** | **Selected** |
| Fraud Transaction Detector | 3 | 5 | 3 | 4 | 15 / 20 | Deferred |
| Customer Churn Predictor | 4 | 4 | 3 | 4 | 15 / 20 | Deferred |
| Credit Limit Optimizer | 2 | 4 | 4 | 3 | 13 / 20 | Deferred |

---

## 3. Rationale for Selecting Credit Card Approval Predictor

- **Dataset Quality and Realism:** The Kaggle "Credit Card Approval Prediction" dataset (provided by author *rikdifos*) offers a dual-table structure (`application_record.csv` and `credit_record.csv`) that simulates a real-world enterprise merge. It demands substantial feature engineering and proxy target modeling, making it ideal for demonstrating end-to-end data pipelines.
- **Regulatory and Interpretability Constraints:** In financial lending, automated decisions are legally subject to "Adverse Action Notices." A bank cannot reject a user without explaining why. This project provides a valuable demonstration of feature importances and local explanation factors (top-3 drivers of approval or rejection).
- **Academic Scoping:** The concept matches the required course architecture (Presentation, Application, Machine Learning, and Data layers) perfectly, without the extreme real-time streaming constraints that a production Fraud Detector would demand.
