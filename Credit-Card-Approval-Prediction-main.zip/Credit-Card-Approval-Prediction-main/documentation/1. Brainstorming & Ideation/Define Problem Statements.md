# Define Problem Statements

This document defines the core business and technical problem statement for the Credit Card Approval Prediction System, highlighting proxy assumptions and modeling constraints.

## 1. Core Problem Statement

Retail banks and financial institutions receive thousands of credit card applications daily. Evaluating these applications manually is slow, costly, and prone to subjective bias. Automating this process using machine learning holds significant value, but it presents two conflicting goals:
1. **Minimize Credit Default Risk:** Prevent approving cards for individuals who are likely to default or experience severe payment delays (which lead to bad debt write-offs).
2. **Maximize Business Growth:** Avoid rejecting creditworthy applicants (false negatives), which results in lost transaction fees, interest revenue, and customer lifetime value.

The core challenge is: **How can a bank accurately, instantly, and transparently predict the default risk of an applicant using demographic and financial profiles?**

---

## 2. Dataset Context & Proxy-Target Labeling

In real-world credit risk projects, we want to predict whether a *new applicant* should be approved. However, historical underwriting approval/rejection decisions are rarely available or they suffer from selection bias (we only have repayment data for people who were *already* approved). 

Therefore, this project employs a **Proxy-Target Assumption**:
- **Source Dataset:** Kaggle - Credit Card Approval Prediction ( rikdifos ).
- **Target Label Construction:** The target label is derived from the applicant's credit repayment history (`credit_record.csv`), which records the monthly payment status:
  - `C`: Co (paid off that month)
  - `X`: No loan for the month
  - `0`: 1-29 days overdue
  - `1`: 30-59 days overdue
  - `2`: 60-89 days overdue
  - `3`: 90-119 days overdue
  - `4`: 120-149 days overdue
  - `5`: Overdue or bad debts, write-offs for more than 150 days

- **Proxy Classification Mapping:**
  - **Approved (Class 0):** Only clean/no-loan statuses (`C`, `X`) occur during the observed window.
  - **Not Approved (Class 1):** Any overdue/delinquency status appears (`0` through `5`) at least once.

---

## 3. Major Technical Constraint: Target Leakage Analysis

> [!WARNING]
> **Critical Design Critique: Target Leakage**
> In the current implementation of `train.py`, features derived from the historical repayment history (`months_overdue`, `severe_delinquency_count`, `months_paid`, `credit_window`) are included in the predictor feature set (`feature_cols`).
> 
> Because the target label is defined directly as `target = 1 if months_overdue > 0 else 0`, this introduces **absolute target leakage**.
> 
> This is why tree-based models (Decision Tree, Random Forest, XGBoost) achieve **100% accuracy and F1-score (1.000)** on the test split. They learn a single trivial decision split:
> `if months_overdue > 0 then Not Approved (1) else Approved (0)`
> 
> **Operational Impact:**
> A model containing target leakage is **unusable in production for new applicants**, because a new applicant who has never been issued a card has no credit history window (`credit_window = 0`, `months_overdue = 0`). The model would predict "Approved" for everyone, regardless of high risk.
> 
> *A path to resolve this is discussed in the Scalability & Future Plan document.*
