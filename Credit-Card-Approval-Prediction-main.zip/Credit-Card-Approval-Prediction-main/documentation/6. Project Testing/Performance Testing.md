# Performance Testing

This document presents the performance testing and evaluation results of the four machine learning models trained on the Credit Card Approval Prediction dataset.

---

## 1. Model Performance Comparison Table

The models were trained using an 80/20 train/test split, stratified by target class and configured with a fixed random seed (`random_state=42`). 

Below are the exact metrics logged in `reports/model_comparison.csv`:

| Model | Accuracy | Precision | Recall | F1-Score | ROC-AUC | PR-AUC | 5-fold CV Accuracy |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| **Decision Tree** | 1.0000 | 1.0000 | 1.0000 | **1.0000** | 1.0000 | 1.0000 | 1.0000 |
| **Random Forest** | 1.0000 | 1.0000 | 1.0000 | **1.0000** | 1.0000 | 1.0000 | 1.0000 |
| **XGBoost** | 1.0000 | 1.0000 | 1.0000 | **1.0000** | 1.0000 | 1.0000 | 1.0000 |
| **Logistic Regression** | 0.9908 | 1.0000 | 0.9895 | **0.9947** | 0.9999 | 1.0000 | 0.9873 |

*Note: Models are sorted by F1-Score. The best model selected by the script and serialized to disk is the **Decision Tree** (or Random Forest/XGBoost, which tied at 1.0).*

---

## 2. Technical Diagnostic: Target Leakage Analysis

> [!IMPORTANT]
> **Why are tree-based metrics perfectly 1.0?**
> In the data pipeline, the target variable `target` is defined as `1` if an applicant has ever had any overdue status code (`0` to `5`) in their payment history, and `0` if their statuses are clean (`C` or `X`).
> 
> The feature set passed to the models contains:
> - `months_overdue`: Sum of months with status in `{"0", "1", "2", "3", "4", "5"}`.
> - `severe_delinquency_count`: Sum of months with status in `{"3", "4", "5"}`.
> 
> Because `target` is exactly determined by `months_overdue > 0`, the tree-based classifiers instantly identify this relationship. They split on `months_overdue` and achieve 100% accuracy, zero misclassifications, and a perfect F1-score on both train and test splits.
> 
> Logistic Regression also achieves near-perfect metrics (accuracy of `99.08%`), showing a minor deviation only because the L2 regularization/optimization algorithm restricts absolute coefficient sizes.

---

## 3. Implications for Production Deployment

While 100% metrics look excellent in academic reports, they represent **target leakage** and are not viable in production:
1. **Zero Utility for New Applicants:** A new credit card applicant has no payment history with the bank. Therefore, their `months_overdue` and `severe_delinquency_count` are both `0`. The model will predict "Approved (0)" for all new applicants, regardless of high risk.
2. **Path to Resolution:** To make this model production-ready for new-applicant underwriting, the credit record summary features must be completely removed from the training features (`feature_cols`). The model must be trained *only* on demographic inputs (`gender`, `annual_income`, `age_years`, `employment_years`, `education_type`, etc.) and external credit bureau ratings.
