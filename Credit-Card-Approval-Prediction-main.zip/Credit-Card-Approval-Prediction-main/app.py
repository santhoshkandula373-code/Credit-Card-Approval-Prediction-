"""Flask app for Credit Card Approval Prediction System."""

from __future__ import annotations

import os
from typing import Any, Dict, List, Tuple

import joblib
import numpy as np
import pandas as pd
from flask import Flask, render_template, request


# ==============================
# Config / constants section
# ==============================
PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
MODEL_DIR = os.path.join(PROJECT_ROOT, "saved_model")
PREPROCESSOR_PATH = os.path.join(MODEL_DIR, "preprocessor.pkl")
MODEL_PATH = os.path.join(MODEL_DIR, "model.pkl")

app = Flask(__name__)


def load_artifacts() -> Tuple[Dict[str, Any], Dict[str, Any]]:
    """Load persisted preprocessor and model artifacts at startup."""
    if not os.path.exists(PREPROCESSOR_PATH) or not os.path.exists(MODEL_PATH):
        raise FileNotFoundError(
            "Missing saved artifacts. Run train.py first to create "
            "saved_model/preprocessor.pkl and saved_model/model.pkl."
        )

    preprocessor_bundle = joblib.load(PREPROCESSOR_PATH)
    model_bundle = joblib.load(MODEL_PATH)
    return preprocessor_bundle, model_bundle


try:
    PREPROCESSOR_BUNDLE, MODEL_BUNDLE = load_artifacts()
except FileNotFoundError as exc:
    PREPROCESSOR_BUNDLE = None
    MODEL_BUNDLE = None
    STARTUP_ERROR = str(exc)
else:
    STARTUP_ERROR = ""


def labelify(feature_name: str) -> str:
    """Convert feature snake_case names into user-friendly labels."""
    return feature_name.replace("scaled_", "").replace("_", " ").title()


def parse_form(form: Dict[str, str]) -> Tuple[Dict[str, Any], str]:
    """Parse and validate incoming form values."""
    try:
        payload = {
            "gender": form.get("gender", "").strip(),
            "income_type": form.get("income_type", "").strip(),
            "education_type": form.get("education_type", "").strip(),
            "family_status": form.get("family_status", "").strip(),
            "housing_type": form.get("housing_type", "").strip(),
            "occupation_type": form.get("occupation_type", "").strip(),
            "annual_income": float(form.get("annual_income", 0)),
            "age_years": float(form.get("age_years", 0)),
            "employment_years": float(form.get("employment_years", 0)),
            "children_count": float(form.get("children_count", 0)),
            "family_members": float(form.get("family_members", 0)),
            "family_dependency": float(form.get("children_count", 0))
            + float(form.get("family_members", 0)),
            "credit_open_month": float(form.get("credit_open_month", -24)),
            "credit_end_month": float(form.get("credit_end_month", 0)),
            "credit_window": float(form.get("credit_window", 24)),
            "months_no_loan": float(form.get("months_no_loan", 0)),
            "months_paid": float(form.get("months_paid", 0)),
            "months_overdue": float(form.get("months_overdue", 0)),
            "severe_delinquency_count": float(form.get("severe_delinquency_count", 0)),
        }
    except ValueError:
        return {}, "Please enter valid numeric values in numeric fields."

    if payload["annual_income"] <= 0:
        return {}, "Annual income must be greater than 0."
    if payload["age_years"] <= 18:
        return {}, "Age must be greater than 18 years."
    if payload["employment_years"] < 0:
        return {}, "Employment duration cannot be negative."
    if payload["children_count"] < 0:
        return {}, "Children count cannot be negative."
    if payload["family_members"] < 1:
        return {}, "Family members must be at least 1."

    required_text = [
        "gender",
        "income_type",
        "education_type",
        "family_status",
        "housing_type",
        "occupation_type",
    ]
    for key in required_text:
        if not payload[key]:
            return {}, f"{labelify(key)} is required."

    return payload, ""


def local_top_factors(
    transformed_vector: np.ndarray,
    model_bundle: Dict[str, Any],
    top_n: int = 3,
) -> List[Dict[str, str]]:
    """Compute top signed local factors for one prediction.

    Positive contribution means pushing toward class 1 (Not Approved),
    which decreases approval likelihood.
    """
    feature_names = model_bundle["feature_names"]
    explanation = model_bundle["explanation"]
    method = explanation["method"]

    x = transformed_vector.ravel()

    if method == "logistic_coefficients":
        # Signed linear contribution per feature.
        signs = np.array(explanation["direction"])
        mags = np.array(explanation["global_importance"])
        contribution = x * signs * mags
    else:
        # Proxy directional local influence for tree models.
        importances = np.array(explanation["global_importance"])
        direction = np.array(explanation["direction"])
        centers = np.array(explanation["centers"])
        contribution = (x - centers) * direction * importances

    top_idx = np.argsort(np.abs(contribution))[::-1][:top_n]

    factors: List[Dict[str, str]] = []
    for idx in top_idx:
        toward_rejection = contribution[idx] > 0
        factors.append(
            {
                "feature": labelify(feature_names[idx]),
                "effect": (
                    "decreased approval likelihood"
                    if toward_rejection
                    else "increased approval likelihood"
                ),
            }
        )

    return factors


@app.route("/")
def home() -> str:
    """Render home page."""
    return render_template("home.html", startup_error=STARTUP_ERROR)


@app.route("/predict", methods=["GET", "POST"])
def predict() -> str:
    """Render input form and prediction result."""
    if STARTUP_ERROR:
        return render_template("index.html", error=STARTUP_ERROR, form_data={})

    if request.method == "GET":
        return render_template("index.html", error="", form_data={})

    payload, error = parse_form(request.form)
    if error:
        return render_template("index.html", error=error, form_data=request.form)

    preprocessor = PREPROCESSOR_BUNDLE["preprocessor"]
    feature_cols = PREPROCESSOR_BUNDLE["feature_cols"]

    input_df = pd.DataFrame([payload], columns=feature_cols)

    transformed_all = preprocessor.transform(input_df)
    model = MODEL_BUNDLE["model"]
    feature_indices = np.array(MODEL_BUNDLE["feature_indices"])

    transformed_selected = transformed_all[:, feature_indices]

    pred = int(model.predict(transformed_selected)[0])
    prob_not_approved = float(model.predict_proba(transformed_selected)[0, 1])
    prob_approved = 1.0 - prob_not_approved

    prediction_label = "Not Approved" if pred == 1 else "Approved"
    confidence = prob_not_approved if pred == 1 else prob_approved

    top_factors = local_top_factors(transformed_selected, MODEL_BUNDLE, top_n=3)

    return render_template(
        "result.html",
        prediction=prediction_label,
        confidence=round(confidence * 100, 2),
        top_factors=top_factors,
        model_name=MODEL_BUNDLE["name"],
    )


if __name__ == "__main__":
    app.run(debug=True)
