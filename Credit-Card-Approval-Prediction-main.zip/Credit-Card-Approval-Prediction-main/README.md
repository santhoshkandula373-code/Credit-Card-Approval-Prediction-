# Credit Card Approval Prediction System

## Project Overview
This project predicts credit card application outcome (Approved or Not Approved) using applicant demographic/financial data merged with historical credit repayment records.

The system includes:
- End-to-end data preprocessing and feature engineering.
- Four ML models: Logistic Regression, Decision Tree, Random Forest, XGBoost.
- Model comparison with imbalanced-data metrics (including PR-AUC).
- F1-based best-model selection.
- Flask web app for interactive prediction and explanation.
- A complete phase-wise project documentation set (this folder).

## Dataset
Source: Kaggle - Credit Card Approval Prediction (author: rikdifos)

Required files (place in data/):
- application_record.csv
- credit_record.csv

The project explicitly does not use the mlg-ulb credit card fraud transaction dataset.

### Proxy-Target Assumption (Important)
The target label in this project is a proxy label derived from repayment STATUS history:
- Approved (0): only clean/no-loan statuses (C, X)
- Not Approved (1): any overdue/bad status appears (0-5)

This is not the bank's historical underwriting approval/rejection label. It is a documented modeling assumption for academic scope.

## Repository Folder Structure

```text
Credit_Card_Approval_Prediction_System/
|-- app.py
|-- train.py
|-- requirements.txt
|-- README.md
|-- data/
|   |-- application_record.csv
|   |-- credit_record.csv
|-- saved_model/
|   |-- preprocessor.pkl
|   |-- model.pkl
|-- reports/
|   |-- accuracy.txt
|   |-- classification_report.txt
|   |-- confusion_matrix.png
|   |-- roc_curve.png
|   |-- precision_recall_curve.png
|   |-- feature_importance.png
|   |-- model_comparison.csv
|   |-- train_split_train.csv
|   |-- train_split_test.csv
|   |-- train_test_split_summary.txt
|   |-- eda_countplots.png
|   |-- eda_correlation_heatmap.png
|   |-- eda_describe.csv
|-- templates/
|   |-- home.html
|   |-- index.html
|   |-- result.html
|-- Project Documentation/
|   |-- README.md                                            (this file)
|   |-- 1. Brainstorming & Ideation/
|   |   |-- Brainstorming & Idea Prioritization.md
|   |   |-- Define Problem Statements .md
|   |   |-- Empathy Map.md
|   |-- 2. Requirement Analysis/
|   |   |-- Customer Journey Map.md
|   |   |-- Data Flow Diagram.md
|   |   |-- Solution Requirements.md
|   |   |-- Technology Stack.md
|   |-- 3. Project Design Phase/
|   |   |-- Problem-Solution Fit.md
|   |   |-- Proposed Solution.md
|   |   |-- Solution Architecture.md
|   |-- 4. Project Planning Phase/
|   |   |-- Project Planning.md
|   |-- 5. Project Development Phase/
|   |   |-- Code-Layout, Readability and Reusability.md
|   |   |-- Coding & Solution.md
|   |   |-- No. of Functional Features Included in the Solution.md
|   |-- 6. Project Testing/
|   |   |-- Performance Testing.md
|   |-- 7. Project Documentation/
|   |   |-- Project Executable Files.md
|   |   |-- Sample Project Documentation.md
|   |-- 8. Project Demonstration/
|       |-- Communication.md
|       |-- Demonstration of Proposed Features.md
|       |-- Project Demo Planning.md
|       |-- Scalability & Future Plan.md
|       |-- Team Involvement in Demonstration.md
```

## Setup and Installation
1. Create/activate your Anaconda environment.
2. Install dependencies:

```bash
pip install -r requirements.txt
```

3. Place dataset files in data/.
4. Train and generate artifacts:

```bash
python train.py
```

5. Run Flask app:

```bash
python app.py
```

6. Open in browser:

http://127.0.0.1:5000/

## Modeling Details
- train_test_split(test_size=0.2, random_state=42, stratify=y)
- Explicit split artifacts are exported for review:
  - reports/train_split_train.csv
  - reports/train_split_test.csv
  - reports/train_test_split_summary.txt
- Fixed random_state=42 for all model constructors.
- Unified preprocessing in one fitted ColumnTransformer artifact:
  - OrdinalEncoder for categorical features with unseen-category handling.
  - Numeric raw branch (for tree-based models).
  - Numeric StandardScaler branch (for Logistic Regression only).
- Class imbalance handling:
  - class_weight='balanced' for Logistic Regression, Decision Tree, Random Forest when imbalance > 70:30.
  - scale_pos_weight for XGBoost.
- Evaluation metrics:
  - Accuracy, Precision, Recall, F1, ROC-AUC, PR-AUC, 5-fold CV accuracy.
- Best model selected using F1 score.

## Architecture Mapping (Instructor Diagram)
- Presentation Layer:
  - templates/home.html
  - templates/index.html
  - templates/result.html
- Application Layer (Flask):
  - app.py handles routing, input validation, preprocessing, model loading, prediction, and result rendering.
- Machine Learning Layer:
  - train.py trains Logistic Regression, Decision Tree, Random Forest, and XGBoost.
  - Evaluation and comparison outputs are stored in reports/.
- Data Layer:
  - Raw sources in data/application_record.csv and data/credit_record.csv.
  - Cleaning, merge, feature engineering, and train/test split occur in train.py.
  - Processed train/test exports are stored in reports/train_split_train.csv and reports/train_split_test.csv.
- Model Storage:
  - saved_model/model.pkl (best model)
  - saved_model/preprocessor.pkl (single unified preprocessing object)

Notes about intentional differences from the generic architecture image:
- Best model is selected by F1 score (not accuracy) because this target is imbalanced.
- Preprocessing is persisted as one object (preprocessor.pkl), not separate scaler/encoder files, to prevent inference drift.
- "Prediction history" UI and cloud deployment blocks are out of scope for this academic submission unless explicitly requested.

## Saved Model Comparison Artifact
- reports/model_comparison.csv (machine-readable, graded deliverable)
- Columns:
  - Accuracy
  - Precision
  - Recall
  - F1
  - ROC-AUC
  - PR-AUC
  - 5-fold CV Accuracy

## Flask App Behavior
- Home page with overview and navigation.
- Prediction form with validation:
  - annual_income > 0
  - age_years > 18
  - employment_years >= 0
  - children_count >= 0
  - family_members >= 1
- Result page shows:
  - Approved / Not Approved
  - Confidence percentage
  - Top 3 influential features for that specific prediction, each labeled as increasing or decreasing approval likelihood.

## Project Documentation Folder
The `Project Documentation/` folder (structure above) contains the full phase-wise submission documentation, matching the standard SmartBridge/IBM SkillsBuild template:

| Phase | Contents |
|-------|----------|
| 1. Brainstorming & Ideation | Idea generation/prioritization, problem statements, empathy map |
| 2. Requirement Analysis | Customer journey, data flow diagram, solution requirements, technology stack |
| 3. Project Design Phase | Problem-solution fit, proposed solution, solution architecture |
| 4. Project Planning Phase | Milestones, task ownership, risk management |
| 5. Project Development Phase | Code layout/readability/reusability, coding & solution details, functional feature list |
| 6. Project Testing | Performance testing, model comparison results, functional test cases |
| 7. Project Documentation | Executable files & setup guide, sample project documentation summary |
| 8. Project Demonstration | Communication guide, feature demonstration script, demo planning, scalability & future plan, team involvement |

Each `.md` file is filled in with real project details (actual metrics, actual code structure, actual dataset) rather than generic placeholders. See `Project Documentation/6. Project Testing/Performance Testing.md` in particular for an important caveat on the near-perfect model scores caused by the proxy-target design.

## Conclusion
This system demonstrates a complete academic ML workflow for credit card approval prediction using merged application and repayment-history data. Logistic Regression, Decision Tree, Random Forest, and XGBoost are compared under imbalanced-class evaluation, the best model is selected by F1 score, and deployed through a Flask interface for end-to-end local usage.

## Screenshot Placeholders

### Home Page
![Home Page Placeholder](reports/screenshots/home_page_placeholder.png)
Caption: Landing page showing project overview and navigation to prediction form.

### Prediction Form Page
![Prediction Form Placeholder](reports/screenshots/prediction_form_placeholder.png)
Caption: Input form for applicant and credit-summary features.

### Result Page
![Result Page Placeholder](reports/screenshots/result_page_placeholder.png)
Caption: Predicted approval status, confidence score, and top-3 influencing factors.

### Model Comparison Table
![Model Comparison Placeholder](reports/screenshots/model_comparison_placeholder.png)
Caption: Comparison across Accuracy, Precision, Recall, F1, ROC-AUC, PR-AUC, and CV accuracy.

### Key EDA Visualizations
![EDA Placeholder](reports/screenshots/eda_plots_placeholder.png)
Caption: Categorical distributions and numerical correlation heatmap.