# 🎥 Project Demo Video

The demo video for the **Credit Card Approval Prediction System** is available at the link below.

## Google Drive

**Demo Video:**  
https://drive.google.com/drive/folders/1iqkQW1RrePGXEnxpy1fM6ksuTWu3ZEk0?usp=sharing

> If you have trouble accessing the video, please ensure you have permission to view the shared folder. Make sure the folder is shared as **Anyone with the link can view**. :contentReference[oaicite:0]{index=0}

contact:gnanasathwick@gmail.com