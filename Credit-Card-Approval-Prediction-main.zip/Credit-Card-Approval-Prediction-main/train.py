"""Training pipeline for Credit Card Approval Prediction System.

This script:
1. Loads application and credit records.
2. Cleans and engineers features.
3. Builds a unified preprocessing ColumnTransformer.
4. Trains four models.
5. Evaluates and saves reports/artifacts.
6. Persists one fitted preprocessor and one selected model artifact.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Any, Dict, List, Tuple

import joblib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    auc,
    classification_report,
    confusion_matrix,
    precision_recall_curve,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
    roc_curve,
)
from sklearn.model_selection import cross_val_score, train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import LabelEncoder, OrdinalEncoder, StandardScaler
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from xgboost import XGBClassifier


# ==============================
# Config / constants section
# ==============================
RANDOM_STATE = 42
PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(PROJECT_ROOT, "data")
REPORTS_DIR = os.path.join(PROJECT_ROOT, "reports")
MODEL_DIR = os.path.join(PROJECT_ROOT, "saved_model")

APPLICATION_PATH = os.path.join(DATA_DIR, "application_record.csv")
CREDIT_PATH = os.path.join(DATA_DIR, "credit_record.csv")

PREPROCESSOR_PATH = os.path.join(MODEL_DIR, "preprocessor.pkl")
MODEL_PATH = os.path.join(MODEL_DIR, "model.pkl")


@dataclass
class ModelResult:
    name: str
    estimator: Any
    feature_indices: np.ndarray
    feature_names: List[str]
    y_pred: np.ndarray
    y_proba: np.ndarray
    accuracy: float
    precision: float
    recall: float
    f1: float
    roc_auc: float
    pr_auc: float
    cv_accuracy: float
    confusion: np.ndarray
    report_text: str


def save_train_test_artifacts(
    x_train_df: pd.DataFrame,
    x_test_df: pd.DataFrame,
    y_train: np.ndarray,
    y_test: np.ndarray,
) -> None:
    """Persist explicit train/test split files and a summary for grading transparency."""
    train_out = x_train_df.copy()
    test_out = x_test_df.copy()

    train_out["target"] = y_train
    test_out["target"] = y_test

    train_path = os.path.join(REPORTS_DIR, "train_split_train.csv")
    test_path = os.path.join(REPORTS_DIR, "train_split_test.csv")
    summary_path = os.path.join(REPORTS_DIR, "train_test_split_summary.txt")

    train_out.to_csv(train_path, index=False)
    test_out.to_csv(test_path, index=False)

    train_dist = pd.Series(y_train).value_counts(normalize=True).sort_index() * 100
    test_dist = pd.Series(y_test).value_counts(normalize=True).sort_index() * 100

    with open(summary_path, "w", encoding="utf-8") as f:
        f.write("Train/Test Split Summary\n")
        f.write("========================\n")
        f.write(f"Train rows: {len(train_out)}\n")
        f.write(f"Test rows: {len(test_out)}\n")
        f.write(f"Split ratio: {len(train_out)/(len(train_out)+len(test_out)):.2%} train / ")
        f.write(f"{len(test_out)/(len(train_out)+len(test_out)):.2%} test\n")
        f.write("\nTarget distribution (%):\n")
        f.write("Train:\n")
        f.write(train_dist.to_string())
        f.write("\n\nTest:\n")
        f.write(test_dist.to_string())

    print(f"Saved train split: {train_path}")
    print(f"Saved test split: {test_path}")
    print(f"Saved split summary: {summary_path}")


def ensure_directories() -> None:
    """Ensure required output directories exist."""
    os.makedirs(REPORTS_DIR, exist_ok=True)
    os.makedirs(MODEL_DIR, exist_ok=True)


def load_data() -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Load raw CSV files from the data folder."""
    if not os.path.exists(APPLICATION_PATH):
        raise FileNotFoundError(
            f"Missing file: {APPLICATION_PATH}. Place application_record.csv in data/."
        )
    if not os.path.exists(CREDIT_PATH):
        raise FileNotFoundError(
            f"Missing file: {CREDIT_PATH}. Place credit_record.csv in data/."
        )

    app_df = pd.read_csv(APPLICATION_PATH)
    credit_df = pd.read_csv(CREDIT_PATH)

    print("\n=== Dataset Overview ===")
    print("application_record.csv head:\n", app_df.head())
    print("application_record shape:", app_df.shape)
    print("application_record info:")
    print(app_df.info())

    print("\ncredit_record.csv head:\n", credit_df.head())
    print("credit_record shape:", credit_df.shape)
    print("credit_record info:")
    print(credit_df.info())

    return app_df, credit_df


def map_readable_categories(df: pd.DataFrame) -> pd.DataFrame:
    """Map selected raw fields to readable string labels."""
    out = df.copy()

    if "CODE_GENDER" in out.columns:
        out["GENDER"] = out["CODE_GENDER"].map({"M": "Male", "F": "Female"}).fillna("Unknown")
    if "NAME_INCOME_TYPE" in out.columns:
        out["INCOME_TYPE"] = out["NAME_INCOME_TYPE"].astype(str)
    if "NAME_EDUCATION_TYPE" in out.columns:
        out["EDUCATION_TYPE"] = out["NAME_EDUCATION_TYPE"].astype(str)
    if "NAME_FAMILY_STATUS" in out.columns:
        out["FAMILY_STATUS"] = out["NAME_FAMILY_STATUS"].astype(str)
    if "NAME_HOUSING_TYPE" in out.columns:
        out["HOUSING_TYPE"] = out["NAME_HOUSING_TYPE"].astype(str)

    return out


def handle_days_employed(series: pd.Series) -> pd.Series:
    """Handle DAYS_EMPLOYED placeholder value 365243 robustly.

    Placeholder is treated as not currently employed and mapped to 0 employment years.
    """
    cleaned = series.copy()
    cleaned = cleaned.replace(365243, np.nan)
    cleaned = cleaned.where(cleaned <= 0, np.nan)
    employment_years = (cleaned.abs() / 365.25).fillna(0.0)
    return employment_years


def aggregate_credit_history(credit_df: pd.DataFrame) -> pd.DataFrame:
    """Aggregate monthly credit status into applicant-level features and target."""
    cdf = credit_df.copy()

    cdf["MONTHS_BALANCE"] = pd.to_numeric(cdf["MONTHS_BALANCE"], errors="coerce")
    cdf["STATUS"] = cdf["STATUS"].astype(str)

    def summarize(group: pd.DataFrame) -> pd.Series:
        statuses = group["STATUS"].tolist()

        open_month = group["MONTHS_BALANCE"].min()
        end_month = group["MONTHS_BALANCE"].max()
        credit_window = end_month - open_month

        months_no_loan = sum(s == "X" for s in statuses)
        months_paid = sum(s == "C" for s in statuses)
        months_overdue = sum(s in {"0", "1", "2", "3", "4", "5"} for s in statuses)
        severe_delinquency_count = sum(s in {"3", "4", "5"} for s in statuses)

        # Proxy target cutoff:
        # approved(0) if only clean/no-loan history (C, X)
        # not_approved(1) if any overdue code appears (0-5)
        target = int(any(s in {"0", "1", "2", "3", "4", "5"} for s in statuses))

        return pd.Series(
            {
                "credit_open_month": open_month,
                "credit_end_month": end_month,
                "credit_window": credit_window,
                "months_no_loan": months_no_loan,
                "months_paid": months_paid,
                "months_overdue": months_overdue,
                "severe_delinquency_count": severe_delinquency_count,
                "target": target,
            }
        )

    aggregated = cdf.groupby("ID", as_index=False).apply(summarize).reset_index(drop=True)
    return aggregated


def data_cleaning(app_df: pd.DataFrame, credit_df: pd.DataFrame) -> pd.DataFrame:
    """Clean application data, engineer features, and merge with credit summary."""
    df = app_df.copy()

    # Remove duplicate applicant records.
    df = df.drop_duplicates(subset="ID", keep="first")

    # Missing-value diagnostics.
    print("\n=== Missing Values (application) ===")
    print(df.isnull().sum())
    print("\n=== Missing Ratio (application) ===")
    print(df.isnull().mean().sort_values(ascending=False).head(10))

    # Map readable categories before downstream encoding.
    df = map_readable_categories(df)

    # Feature engineering requested in prompt.
    df["age_years"] = (df["DAYS_BIRTH"].abs() / 365.25).round(2)
    df["employment_years"] = handle_days_employed(df["DAYS_EMPLOYED"]).round(2)

    df["children_count"] = pd.to_numeric(df["CNT_CHILDREN"], errors="coerce").fillna(0)
    df["family_members"] = pd.to_numeric(df["CNT_FAM_MEMBERS"], errors="coerce").fillna(1)
    df["family_dependency"] = df["children_count"] + df["family_members"]

    df["annual_income"] = pd.to_numeric(df["AMT_INCOME_TOTAL"], errors="coerce")

    # Keep occupation and impute later to preserve predictive information.
    if "OCCUPATION_TYPE" in df.columns:
        df["occupation_type"] = df["OCCUPATION_TYPE"].astype(str)
    else:
        df["occupation_type"] = "Unknown"

    cleaned_app = df[
        [
            "ID",
            "GENDER",
            "INCOME_TYPE",
            "EDUCATION_TYPE",
            "FAMILY_STATUS",
            "HOUSING_TYPE",
            "occupation_type",
            "annual_income",
            "age_years",
            "employment_years",
            "children_count",
            "family_members",
            "family_dependency",
        ]
    ].copy()

    credit_agg = aggregate_credit_history(credit_df)

    merged = cleaned_app.merge(credit_agg, on="ID", how="inner")

    merged = merged.rename(
        columns={
            "GENDER": "gender",
            "INCOME_TYPE": "income_type",
            "EDUCATION_TYPE": "education_type",
            "FAMILY_STATUS": "family_status",
            "HOUSING_TYPE": "housing_type",
        }
    )

    # Drop rows where required core numeric features are missing after conversion.
    required_numeric = ["annual_income", "age_years", "employment_years"]
    merged = merged.dropna(subset=required_numeric)

    print("\nFinal merged data shape:", merged.shape)
    return merged


def run_eda(df: pd.DataFrame) -> None:
    """Generate EDA artifacts requested in specification."""
    sns.set_style("whitegrid")

    categorical_for_eda = ["occupation_type", "income_type", "education_type", "family_status"]
    for col in categorical_for_eda:
        print(f"\nValue counts for {col}:")
        print(df[col].value_counts(dropna=False).head(20))

    fig, axes = plt.subplots(2, 2, figsize=(14, 10))
    for ax, col in zip(axes.ravel(), categorical_for_eda):
        sns.countplot(data=df, y=col, order=df[col].value_counts().index[:10], ax=ax)
        ax.set_title(f"Count Plot: {col}")
        ax.set_xlabel("Count")
        ax.set_ylabel(col)
    plt.tight_layout()
    plt.savefig(os.path.join(REPORTS_DIR, "eda_countplots.png"), dpi=200)
    plt.close()

    numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    corr = df[numeric_cols].corr(numeric_only=True)

    plt.figure(figsize=(12, 9))
    sns.heatmap(corr, cmap="coolwarm", center=0)
    plt.title("Correlation Heatmap (Numerical Features)")
    plt.tight_layout()
    plt.savefig(os.path.join(REPORTS_DIR, "eda_correlation_heatmap.png"), dpi=200)
    plt.close()

    desc = df[numeric_cols].describe().T
    desc.to_csv(os.path.join(REPORTS_DIR, "eda_describe.csv"))
    print("\n=== Descriptive Statistics ===")
    print(desc)


def class_imbalance_decision(y: pd.Series) -> Dict[str, Any]:
    """Check imbalance and return class-balancing settings."""
    class_counts = y.value_counts().sort_index()
    class_pct = y.value_counts(normalize=True).sort_index() * 100

    print("\n=== Class Distribution ===")
    print("Counts:\n", class_counts)
    print("Percentages (%):\n", class_pct.round(2))

    majority_ratio = class_pct.max() / 100
    use_balanced = majority_ratio > 0.70

    if use_balanced:
        print("Imbalance exceeds ~70:30. Applying class_weight='balanced' for sklearn models.")
    else:
        print("Imbalance within ~70:30. Using default class weights.")

    neg = (y == 0).sum()
    pos = (y == 1).sum()
    scale_pos_weight = float(neg / max(pos, 1))

    return {
        "use_balanced": use_balanced,
        "class_weight": "balanced" if use_balanced else None,
        "scale_pos_weight": scale_pos_weight,
    }


def build_preprocessor(categorical_cols: List[str], numeric_cols: List[str]) -> ColumnTransformer:
    """Build unified preprocessor with encoded categoricals + raw and scaled numeric branches."""
    cat_pipeline = Pipeline(
        steps=[
            ("imputer", SimpleImputer(strategy="most_frequent")),
            (
                "encoder",
                OrdinalEncoder(
                    handle_unknown="use_encoded_value",
                    unknown_value=-1,
                ),
            ),
        ]
    )

    num_raw_pipeline = Pipeline(
        steps=[
            ("imputer", SimpleImputer(strategy="median")),
        ]
    )

    num_scaled_pipeline = Pipeline(
        steps=[
            ("imputer", SimpleImputer(strategy="median")),
            ("scaler", StandardScaler()),
        ]
    )

    preprocessor = ColumnTransformer(
        transformers=[
            ("cat", cat_pipeline, categorical_cols),
            ("num_raw", num_raw_pipeline, numeric_cols),
            ("num_scaled", num_scaled_pipeline, numeric_cols),
        ],
        remainder="drop",
        sparse_threshold=0,
    )

    return preprocessor


def get_feature_layout(
    categorical_cols: List[str], numeric_cols: List[str]
) -> Dict[str, Any]:
    """Return feature names and branch indices after unified transform."""
    cat_names = categorical_cols
    raw_names = numeric_cols
    scaled_names = [f"scaled_{c}" for c in numeric_cols]

    all_names = cat_names + raw_names + scaled_names

    cat_end = len(cat_names)
    raw_end = cat_end + len(raw_names)
    scaled_end = raw_end + len(raw_names)

    tree_indices = np.arange(0, raw_end)
    lr_indices = np.concatenate([np.arange(0, cat_end), np.arange(raw_end, scaled_end)])

    tree_feature_names = all_names[:raw_end]
    lr_feature_names = all_names[:cat_end] + all_names[raw_end:scaled_end]

    return {
        "all_feature_names": all_names,
        "tree_indices": tree_indices,
        "lr_indices": lr_indices,
        "tree_feature_names": tree_feature_names,
        "lr_feature_names": lr_feature_names,
    }


def train_logistic(
    x_train: np.ndarray,
    y_train: np.ndarray,
    class_weight: Any,
) -> LogisticRegression:
    """Train Logistic Regression model."""
    return LogisticRegression(
        solver="liblinear",
        max_iter=1000,
        random_state=RANDOM_STATE,
        class_weight=class_weight,
    ).fit(x_train, y_train)


def d_tree(x_train: np.ndarray, y_train: np.ndarray, class_weight: Any) -> DecisionTreeClassifier:
    """Train Decision Tree model."""
    return DecisionTreeClassifier(
        random_state=RANDOM_STATE,
        class_weight=class_weight,
    ).fit(x_train, y_train)


def random_forest(
    x_train: np.ndarray, y_train: np.ndarray, class_weight: Any
) -> RandomForestClassifier:
    """Train Random Forest model."""
    return RandomForestClassifier(
        n_estimators=300,
        random_state=RANDOM_STATE,
        class_weight=class_weight,
        n_jobs=-1,
    ).fit(x_train, y_train)


def train_xgboost(
    x_train: np.ndarray,
    y_train: np.ndarray,
    scale_pos_weight: float,
) -> XGBClassifier:
    """Train XGBoost model with explicit binary params."""
    return XGBClassifier(
        objective="binary:logistic",
        eval_metric="logloss",
        random_state=RANDOM_STATE,
        n_estimators=300,
        learning_rate=0.05,
        max_depth=5,
        subsample=0.9,
        colsample_bytree=0.9,
        scale_pos_weight=scale_pos_weight,
        n_jobs=-1,
    ).fit(x_train, y_train)


def evaluate_model(
    name: str,
    estimator: Any,
    feature_indices: np.ndarray,
    feature_names: List[str],
    x_train_all: np.ndarray,
    x_test_all: np.ndarray,
    y_train: np.ndarray,
    y_test: np.ndarray,
) -> ModelResult:
    """Evaluate a fitted model and return structured metrics."""
    x_train = x_train_all[:, feature_indices]
    x_test = x_test_all[:, feature_indices]

    y_pred = estimator.predict(x_test)
    y_proba = estimator.predict_proba(x_test)[:, 1]

    acc = accuracy_score(y_test, y_pred)
    prec = precision_score(y_test, y_pred, zero_division=0)
    rec = recall_score(y_test, y_pred, zero_division=0)
    f1 = f1_score(y_test, y_pred, zero_division=0)
    roc_auc = roc_auc_score(y_test, y_proba)

    pr_p, pr_r, _ = precision_recall_curve(y_test, y_proba)
    pr_auc = auc(pr_r, pr_p)

    cv_scores = cross_val_score(estimator, x_train, y_train, cv=5, scoring="accuracy", n_jobs=-1)

    conf = confusion_matrix(y_test, y_pred)
    report = classification_report(y_test, y_pred, digits=4)

    return ModelResult(
        name=name,
        estimator=estimator,
        feature_indices=feature_indices,
        feature_names=feature_names,
        y_pred=y_pred,
        y_proba=y_proba,
        accuracy=acc,
        precision=prec,
        recall=rec,
        f1=f1,
        roc_auc=roc_auc,
        pr_auc=pr_auc,
        cv_accuracy=float(cv_scores.mean()),
        confusion=conf,
        report_text=report,
    )


def save_confusion_heatmap(conf: np.ndarray, model_name: str) -> None:
    """Save confusion_matrix.png as a labeled seaborn heatmap."""
    plt.figure(figsize=(6, 5))
    sns.heatmap(
        conf,
        annot=True,
        fmt="d",
        cmap="Blues",
        xticklabels=["Approved (0)", "Not Approved (1)"],
        yticklabels=["Approved (0)", "Not Approved (1)"],
    )
    plt.xlabel("Predicted Label")
    plt.ylabel("Actual Label")
    plt.title(f"Confusion Matrix - {model_name}")
    plt.tight_layout()
    plt.savefig(os.path.join(REPORTS_DIR, "confusion_matrix.png"), dpi=220)
    plt.close()


def save_roc_pr_curves(results: List[ModelResult], y_test: np.ndarray) -> None:
    """Save combined ROC and Precision-Recall curves for all models."""
    plt.figure(figsize=(8, 6))
    for res in results:
        fpr, tpr, _ = roc_curve(y_test, res.y_proba)
        plt.plot(fpr, tpr, label=f"{res.name} (AUC={res.roc_auc:.3f})")
    plt.plot([0, 1], [0, 1], "k--", linewidth=1)
    plt.xlabel("False Positive Rate")
    plt.ylabel("True Positive Rate")
    plt.title("ROC Curve")
    plt.legend()
    plt.tight_layout()
    plt.savefig(os.path.join(REPORTS_DIR, "roc_curve.png"), dpi=220)
    plt.close()

    plt.figure(figsize=(8, 6))
    for res in results:
        pr_p, pr_r, _ = precision_recall_curve(y_test, res.y_proba)
        plt.plot(pr_r, pr_p, label=f"{res.name} (PR-AUC={res.pr_auc:.3f})")
    plt.xlabel("Recall")
    plt.ylabel("Precision")
    plt.title("Precision-Recall Curve")
    plt.legend()
    plt.tight_layout()
    plt.savefig(os.path.join(REPORTS_DIR, "precision_recall_curve.png"), dpi=220)
    plt.close()


def save_feature_importance(
    best_result: ModelResult,
    x_train_selected: np.ndarray,
    y_train: np.ndarray,
) -> Dict[str, Any]:
    """Save feature importance figure and explanation metadata."""
    model = best_result.estimator
    names = best_result.feature_names

    if isinstance(model, LogisticRegression):
        coef = model.coef_[0]
        order = np.argsort(np.abs(coef))[::-1][:20]
        plt.figure(figsize=(10, 7))
        colors = ["#D1495B" if coef[i] > 0 else "#2E86AB" for i in order]
        plt.barh([names[i] for i in order][::-1], coef[order][::-1], color=colors[::-1])
        plt.xlabel("Coefficient (signed)")
        plt.title("Logistic Regression Coefficients (Feature Importance Equivalent)")
        plt.tight_layout()
        plt.savefig(os.path.join(REPORTS_DIR, "feature_importance.png"), dpi=220)
        plt.close()

        return {
            "method": "logistic_coefficients",
            "global_importance": np.abs(coef).tolist(),
            "direction": np.sign(coef).tolist(),
            "centers": np.zeros_like(coef).tolist(),
        }

    if hasattr(model, "feature_importances_"):
        importances = model.feature_importances_
        order = np.argsort(importances)[::-1][:20]

        plt.figure(figsize=(10, 7))
        sns.barplot(x=importances[order], y=[names[i] for i in order], orient="h", color="#2E86AB")
        plt.xlabel("Importance")
        plt.title(f"Feature Importance - {best_result.name}")
        plt.tight_layout()
        plt.savefig(os.path.join(REPORTS_DIR, "feature_importance.png"), dpi=220)
        plt.close()

        # Approximate directional tendency for local explanation.
        centers = np.median(x_train_selected, axis=0)
        direction = []
        for i in range(x_train_selected.shape[1]):
            xi = x_train_selected[:, i]
            if np.std(xi) < 1e-8:
                direction.append(0.0)
            else:
                corr = np.corrcoef(xi, y_train)[0, 1]
                direction.append(float(np.nan_to_num(np.sign(corr), nan=0.0)))

        return {
            "method": "tree_importance_directional_proxy",
            "global_importance": importances.tolist(),
            "direction": direction,
            "centers": centers.tolist(),
        }

    raise ValueError("Selected model does not expose known importance attributes.")


def main() -> None:
    """Run the full training and artifact generation flow."""
    ensure_directories()

    app_df, credit_df = load_data()
    merged = data_cleaning(app_df, credit_df)

    run_eda(merged)

    target = merged["target"].astype(int)

    # Target encoder is retained per requirement; binary is already 0/1.
    label_encoder = LabelEncoder()
    y = label_encoder.fit_transform(target)

    feature_cols = [
        "gender",
        "income_type",
        "education_type",
        "family_status",
        "housing_type",
        "occupation_type",
        "annual_income",
        "age_years",
        "employment_years",
        "children_count",
        "family_members",
        "family_dependency",
        "credit_open_month",
        "credit_end_month",
        "credit_window",
        "months_no_loan",
        "months_paid",
        "months_overdue",
        "severe_delinquency_count",
    ]

    x = merged[feature_cols].copy()

    categorical_cols = [
        "gender",
        "income_type",
        "education_type",
        "family_status",
        "housing_type",
        "occupation_type",
    ]
    numeric_cols = [c for c in feature_cols if c not in categorical_cols]

    x_train_df, x_test_df, y_train, y_test = train_test_split(
        x,
        y,
        test_size=0.2,
        random_state=RANDOM_STATE,
        stratify=y,
    )

    save_train_test_artifacts(x_train_df, x_test_df, y_train, y_test)

    balance_cfg = class_imbalance_decision(pd.Series(y_train))

    preprocessor = build_preprocessor(categorical_cols, numeric_cols)
    x_train_all = preprocessor.fit_transform(x_train_df)
    x_test_all = preprocessor.transform(x_test_df)

    layout = get_feature_layout(categorical_cols, numeric_cols)

    models: List[ModelResult] = []

    lr_model = train_logistic(
        x_train_all[:, layout["lr_indices"]],
        y_train,
        class_weight=balance_cfg["class_weight"],
    )
    models.append(
        evaluate_model(
            "Logistic Regression",
            lr_model,
            layout["lr_indices"],
            layout["lr_feature_names"],
            x_train_all,
            x_test_all,
            y_train,
            y_test,
        )
    )

    dt_model = d_tree(
        x_train_all[:, layout["tree_indices"]],
        y_train,
        class_weight=balance_cfg["class_weight"],
    )
    models.append(
        evaluate_model(
            "Decision Tree",
            dt_model,
            layout["tree_indices"],
            layout["tree_feature_names"],
            x_train_all,
            x_test_all,
            y_train,
            y_test,
        )
    )

    rf_model = random_forest(
        x_train_all[:, layout["tree_indices"]],
        y_train,
        class_weight=balance_cfg["class_weight"],
    )
    models.append(
        evaluate_model(
            "Random Forest",
            rf_model,
            layout["tree_indices"],
            layout["tree_feature_names"],
            x_train_all,
            x_test_all,
            y_train,
            y_test,
        )
    )

    xgb_model = train_xgboost(
        x_train_all[:, layout["tree_indices"]],
        y_train,
        scale_pos_weight=balance_cfg["scale_pos_weight"],
    )
    models.append(
        evaluate_model(
            "XGBoost",
            xgb_model,
            layout["tree_indices"],
            layout["tree_feature_names"],
            x_train_all,
            x_test_all,
            y_train,
            y_test,
        )
    )

    comparison_rows = []
    for res in models:
        comparison_rows.append(
            {
                "Model": res.name,
                "Accuracy": res.accuracy,
                "Precision": res.precision,
                "Recall": res.recall,
                "F1": res.f1,
                "ROC-AUC": res.roc_auc,
                "PR-AUC": res.pr_auc,
                "5-fold CV Accuracy": res.cv_accuracy,
            }
        )

    comparison_df = pd.DataFrame(comparison_rows).sort_values(by="F1", ascending=False)

    print("\n=== Model Comparison (F1-sorted) ===")
    print(comparison_df.to_string(index=False, float_format=lambda v: f"{v:.4f}"))

    comparison_df.to_csv(os.path.join(REPORTS_DIR, "model_comparison.csv"), index=False)

    best_name = comparison_df.iloc[0]["Model"]
    best_result = next(m for m in models if m.name == best_name)

    with open(os.path.join(REPORTS_DIR, "accuracy.txt"), "w", encoding="utf-8") as f:
        for res in models:
            f.write(f"{res.name}: {res.accuracy:.4f}\n")
        f.write(f"\nBest model by F1: {best_result.name} (F1={best_result.f1:.4f})\n")

    with open(os.path.join(REPORTS_DIR, "classification_report.txt"), "w", encoding="utf-8") as f:
        for res in models:
            f.write(f"=== {res.name} ===\n")
            f.write(res.report_text)
            f.write("\n\n")

    save_confusion_heatmap(best_result.confusion, best_result.name)
    save_roc_pr_curves(models, y_test)

    x_train_selected = x_train_all[:, best_result.feature_indices]
    explanation_meta = save_feature_importance(best_result, x_train_selected, y_train)

    preprocessor_bundle = {
        "preprocessor": preprocessor,
        "categorical_cols": categorical_cols,
        "numeric_cols": numeric_cols,
        "feature_cols": feature_cols,
        "layout": {
            "all_feature_names": layout["all_feature_names"],
            "tree_indices": layout["tree_indices"].tolist(),
            "lr_indices": layout["lr_indices"].tolist(),
            "tree_feature_names": layout["tree_feature_names"],
            "lr_feature_names": layout["lr_feature_names"],
        },
        "target_classes": label_encoder.classes_.tolist(),
        "target_definition": "target=1 if any STATUS in {0,1,2,3,4,5}; else 0 for clean/no-loan (C,X)",
    }

    model_bundle = {
        "name": best_result.name,
        "model": best_result.estimator,
        "feature_indices": best_result.feature_indices.tolist(),
        "feature_names": best_result.feature_names,
        "target_positive_label": "Not Approved",
        "target_negative_label": "Approved",
        "explanation": explanation_meta,
    }

    joblib.dump(preprocessor_bundle, PREPROCESSOR_PATH)
    joblib.dump(model_bundle, MODEL_PATH)

    print(f"\nSaved preprocessor: {PREPROCESSOR_PATH}")
    print(f"Saved model: {MODEL_PATH}")
    print(f"Reports generated in: {REPORTS_DIR}")


if __name__ == "__main__":
    main()
